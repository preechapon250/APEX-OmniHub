# APEX-SKILL-FORGE v4.0 (Universal Edition)

**20x Skill Engineering System - Works with ANY LLM**

## What This Is

A **model-agnostic prompting system** that transforms any AI (GPT-4, Claude, Gemini, Llama, Mistral) into an expert skill engineering system.

## Quick Start

### Step 1: Copy the Prompt
```bash
cat UNIVERSAL_PROMPT.md
# Copy the entire contents
```

### Step 2: Paste into ANY AI
Works with:
- ✅ ChatGPT (GPT-4, GPT-4 Turbo)
- ✅ Claude (all versions)
- ✅ Google Gemini
- ✅ Meta Llama
- ✅ Mistral AI
- ✅ Any other LLM

### Step 3: Add Your Request
```
[Paste entire UNIVERSAL_PROMPT.md]

Now apply this protocol to: "Create a skill for processing CSV files"
```

## What Makes This 20x Better?

✅ **Universal** - No platform lock-in, works everywhere  
✅ **Omniscient Intent** - Handles vague/broken requests  
✅ **Zero-Drift** - Consistent output across all models  
✅ **First-Pass Perfect** - 9.5+ quality guaranteed  
✅ **6 Archetypes** - Auto-selects optimal pattern  
✅ **Production Ready** - Battle-tested standards  

## Features

- **No Installation** - Just copy/paste the prompt
- **Platform Independent** - Works with any AI
- **Consistent Output** - Same quality across all models
- **Complete Skills** - Contract, examples, troubleshooting
- **6 Archetypes** - Workflow, Toolkit, Domain, Orchestrator, Transformer, Guardian

## Output Format

Every skill generated includes:
- Contract-first specification (Input/Output/Success/Fails)
- Decision trees (not prose)
- Working code examples
- Failure prevention
- Troubleshooting guide

## Example Usage

### With GPT-4
```
[Paste UNIVERSAL_PROMPT.md]

Now apply this protocol to: "Build a JSON schema validator"
```

### With Claude
```
[Paste UNIVERSAL_PROMPT.md]

Now apply this protocol to: "Create a skill for API testing"
```

### With Gemini
```
[Paste UNIVERSAL_PROMPT.md]

Now apply this protocol to: "Make a skill for data cleaning"
```

**Same prompt works identically across ALL platforms!**

## Files

```
apex-skill-forge-universal/
├── README.md              # This file
├── UNIVERSAL_PROMPT.md    # ⭐ THE KEY FILE - Copy this!
└── LICENSE.md             # Proprietary license
```

## System Requirements

- Any LLM that supports long prompts (~8K tokens)
- No special tools required
- No installation needed

## Support

**APEX Business Systems Ltd.**  
Edmonton, Alberta, Canada  
https://apexbusiness-systems.com

**Key File**: UNIVERSAL_PROMPT.md  
**License**: Proprietary (see LICENSE.md)

---

**Copyright © 2026 APEX Business Systems Ltd. All Rights Reserved.**
