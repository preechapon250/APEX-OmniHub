# LICENSE - APEX-SKILL-FORGE v4.0

**Copyright © 2026 APEX Business Systems Ltd. All Rights Reserved.**

Edmonton, Alberta, Canada  
https://apexbusiness-systems.com

## License Type: Proprietary

This software is proprietary and confidential. All rights reserved.

### Permitted Use
✅ Internal use within your organization  
✅ Install on Claude.ai for authorized users  
✅ Create skills for your projects  
✅ Modify for internal use  

### Prohibited Use
❌ Public distribution or sharing  
❌ Redistribution to third parties  
❌ Removal of copyright notices  
❌ Creating competing products  

### Ownership
- You OWN the skills you create with this system
- APEX retains rights to apex-skill-forge itself

### Warranty
PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND.

### Contact
licensing@apexbusiness-systems.com

**See full license terms at**: https://apexbusiness-systems.com/license
