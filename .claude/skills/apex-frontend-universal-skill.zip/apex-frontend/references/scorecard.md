# Scorecard (Universal)

Target ≥ 90/100
- UX clarity (25)
- UI consistency (20)
- State completeness (10)
- Accessibility (15)
- Performance (15)
- Engineering quality (15)

Auto-fail: missing states, inaccessible primary action, bug fix without repro/prevention.
