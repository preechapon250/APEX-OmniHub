# Motion (Universal)

- Micro interactions 80–180ms; transitions 180–280ms.
- Prefer transform/opacity for smoothness.
- Respect reduced motion.
- Motion must communicate state and feedback; never block progress.
