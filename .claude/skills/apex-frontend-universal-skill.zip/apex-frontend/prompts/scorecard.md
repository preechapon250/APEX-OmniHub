Before finalizing, score the output (0–100) using:
- UX clarity (25)
- UI consistency (20)
- State completeness (10)
- Accessibility (15)
- Performance awareness (15)
- Engineering quality (15)

If < 90, revise the weakest sections and re-check: states + a11y + acceptance criteria.
