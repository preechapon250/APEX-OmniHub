MODE: design  (or audit/implement/debug/perf/a11y/system)

CONTEXT:
- Platform/stack:
- Users/job:
- What I’m building/fixing:
- Constraints (brand/a11y/perf):
- Inputs (specs/screenshots/code/logs):

DELIVERABLES I WANT:
- (e.g., flow + wireframes + screen spec + component list + acceptance criteria)
