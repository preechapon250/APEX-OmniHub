# Performance Budget Template

## Context
- Platform:
- Screen/flow:

## Budgets
- Startup/TTI:
- Scroll smoothness:
- Memory:
- Network payload:

## Measurement method
- Tool:
- Scenario:

## Current baseline
- Observations:
- Bottlenecks:

## Fix plan
- Change:
- Expected impact:
- Risk:

## Regression guard
- Test/CI/monitor:
