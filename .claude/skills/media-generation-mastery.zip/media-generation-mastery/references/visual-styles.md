# Visual Style & Aesthetic Directory

Comprehensive guide to every visual style and aesthetic with specific prompt elements for each. Use this to translate creative direction into precise generation prompts.

## Professional/Corporate Aesthetics (Tone: 1-3)

### Clean Minimalist Corporate
**When to use:** Tech companies, consulting, finance, healthcare

**Visual Elements:**
- Background: Solid white, light gray, or subtle gradient
- Lighting: Soft, even, overhead + fill (no harsh shadows)
- Colors: Navy, gray, white with one accent (blue/teal common)
- Composition: Centered or rule-of-thirds, balanced symmetry
- Typography: Sans-serif (Helvetica, Arial, clean modern fonts)
- Negative space: Generous (60-70% empty space)

**Prompt Elements:**
```
professional corporate photography, clean white background,
soft even lighting, centered composition, minimalist aesthetic,
business professional attire, confident posture,
shallow depth of field, sharp focus,
high-end commercial photography style,
--ar 16:9 --stylize 50
```

### Modern Tech/SaaS
**When to use:** Software, apps, digital products, startups

**Visual Elements:**
- Background: Gradient (purple-to-blue common), or geometric patterns
- Lighting: Bright, slightly dramatic, colored gels optional
- Colors: Purple, blue, teal with white/light gray
- Composition: Layered, depth, floating elements
- Typography: Modern sans-serif, sometimes lowercase
- UI elements: Screens, dashboards, interface mockups

**Prompt Elements:**
```
modern tech aesthetic, gradient background (purple to blue),
clean professional lighting, floating UI elements,
depth and layers, contemporary software design,
high-tech professional photography,
sharp and crisp, editorial tech magazine style,
--ar 16:9 --stylize 75
```

### Corporate Executive
**When to use:** Leadership content, annual reports, enterprise B2B

**Visual Elements:**
- Background: Office, city skyline, professional setting
- Lighting: Premium, sophisticated, directional + fill
- Colors: Navy, black, gray, burgundy, gold accents
- Composition: Confident, authoritative, slightly low-angle
- Environment: Corner office, boardroom, upscale settings
- Details: Watch, suit, executive presence

**Prompt Elements:**
```
executive corporate portrait, premium business environment,
sophisticated directional lighting, confident authoritative pose,
luxury office setting, city skyline background,
professional business attire, high-end commercial photography,
shot with 85mm lens, shallow depth of field,
editorial business magazine style, Forbes aesthetic,
--ar 4:5 --stylize 100
```

---

## Balanced/Versatile Aesthetics (Tone: 4-6)

### Authentic Lifestyle
**When to use:** Consumer brands, lifestyle products, relatable content

**Visual Elements:**
- Background: Real environments (home, cafe, outdoors)
- Lighting: Natural window light, golden hour outdoor
- Colors: Warm, natural, earth tones with vibrant accents
- Composition: Candid, slightly off-center, dynamic
- Expression: Genuine, natural, mid-action
- Context: Everyday moments, relatable scenarios

**Prompt Elements:**
```
authentic lifestyle photography, natural window light,
real home environment, candid moment, genuine expression,
warm color palette, natural earth tones,
shot with 50mm lens, medium depth of field,
lifestyle magazine aesthetic, relatable and approachable,
documentary photography style, organic and unstaged,
--ar 4:5 --stylize 100
```

### Modern Editorial
**When to use:** Fashion, beauty, creative brands, publications

**Visual Elements:**
- Background: Contextual, purposeful, adds to story
- Lighting: Intentional, can be dramatic or soft
- Colors: Cohesive palette, intentional color story
- Composition: Rule of thirds, leading lines, dynamic
- Styling: Curated, designed, every element intentional
- Mood: Aspirational but attainable

**Prompt Elements:**
```
modern editorial photography, curated styling,
intentional color palette, dynamic composition,
contextual background, directional natural light,
fashion magazine aesthetic, shot with 35mm lens,
balanced depth of field, aspirational lifestyle,
editorial storytelling, sophisticated and polished,
--ar 3:4 --stylize 150
```

### Documentary Authentic
**When to use:** Storytelling, non-profit, social impact, journalism

**Visual Elements:**
- Background: Real, unmodified environments
- Lighting: Available light, no artificial enhancement
- Colors: Natural, ungraded, realistic
- Composition: Rule-breaking okay, captures moment
- Expression: Raw, genuine, unposed
- Context: Story-driven, purposeful

**Prompt Elements:**
```
documentary photography style, available natural light,
real unmodified environment, candid authentic moment,
genuine unposed expression, photojournalism aesthetic,
reportage style, natural colors, story-driven composition,
shot with 35mm lens, contextual depth of field,
National Geographic documentary style, raw and real,
--ar 16:9 --stylize 75
```

---

## Creative/Experimental Aesthetics (Tone: 7-10)

### Bold Maximalist
**When to use:** Creative brands, bold products, Gen Z audience

**Visual Elements:**
- Background: Busy, colorful, patterned, layered
- Lighting: High contrast, colored gels, dramatic
- Colors: Saturated, contrasting, multiple bold colors
- Composition: Asymmetrical, overlapping, dense
- Typography: Display fonts, large, decorative
- Effects: Grain, textures, overlays, glitch effects

**Prompt Elements:**
```
bold maximalist aesthetic, vibrant saturated colors,
high contrast dramatic lighting, colored gel effects,
busy patterned background, asymmetrical composition,
dense layered elements, contemporary art style,
oversaturated color grading, editorial fashion photography,
creative and experimental, Memphis design influence,
--ar 9:16 --stylize 200
```

### Cinematic Drama
**When to use:** Film, premium products, storytelling content

**Visual Elements:**
- Background: Moody, atmospheric, depth
- Lighting: Rembrandt, dramatic shadows, side/back light
- Colors: Teal & orange, desaturated with pops
- Composition: Widescreen, leading lines, depth layers
- Atmosphere: Fog, haze, bokeh, film grain
- Quality: Anamorphic lens feel, cinematic depth

**Prompt Elements:**
```
cinematic photography, dramatic Rembrandt lighting,
moody atmospheric background, teal and orange color grade,
shot with anamorphic lens, 2.39:1 aspect ratio,
shallow depth of field, bokeh background,
film grain texture, high contrast shadows,
Hollywood cinematography style, premium production quality,
--ar 21:9 --stylize 250
```

### Retro-Futuristic
**When to use:** Tech with personality, gaming, nostalgic + modern

**Visual Elements:**
- Background: Geometric, grid patterns, neon elements
- Lighting: Neon glow, colored lights, synthwave aesthetic
- Colors: Purple, pink, cyan, with dark backgrounds
- Composition: Symmetrical, centered, bold
- Style: 80s meets future, vaporwave influence
- Effects: Glow, light leaks, chromatic aberration

**Prompt Elements:**
```
retro-futuristic aesthetic, synthwave color palette,
neon lighting (purple, pink, cyan), dark background,
geometric patterns, grid elements, 1980s meets cyberpunk,
vaporwave influence, symmetrical composition,
glow effects, chromatic aberration, nostalgic futurism,
outrun aesthetic, blade runner cinematography style,
--ar 16:9 --stylize 300
```

### Organic Natural
**When to use:** Wellness, sustainability, organic products, nature

**Visual Elements:**
- Background: Natural textures (wood, stone, plants)
- Lighting: Soft diffused natural light, warm tones
- Colors: Earth tones (terracotta, sage, cream, tan)
- Composition: Asymmetrical, organic flow, natural
- Materials: Natural elements, plants, raw materials
- Mood: Calm, grounded, peaceful

**Prompt Elements:**
```
organic natural aesthetic, earth tone color palette,
soft diffused natural lighting, warm golden tones,
natural materials (wood, stone, linen, plants),
botanical elements, asymmetrical organic composition,
calm peaceful mood, minimalist natural styling,
editorial lifestyle photography, Kinfolk magazine aesthetic,
soft focus, gentle shadows, sustainable living style,
--ar 4:5 --stylize 150
```

### Urban Street
**When to use:** Fashion, streetwear, authentic youth culture

**Visual Elements:**
- Background: City streets, graffiti, urban landscapes
- Lighting: Available light, harsh sun, or night neon
- Colors: Desaturated or vibrant, depends on mood
- Composition: Dynamic, candid, rule-breaking
- Style: Raw, authentic, street photography
- Context: Real urban environments, not staged

**Prompt Elements:**
```
urban street photography, city environment,
authentic street style, available natural light,
graffiti background, concrete and brick textures,
candid documentary style, raw and unpolished,
contemporary street photography, hypebeast aesthetic,
shot with 35mm lens, natural colors or desaturated,
dynamic composition, editorial streetwear photography,
--ar 4:5 --stylize 100
```

### Art Deco Luxury
**When to use:** Luxury products, high-end services, premium content

**Visual Elements:**
- Background: Geometric patterns, metallic accents
- Lighting: Dramatic, sculptural, highlighting form
- Colors: Gold, black, navy, burgundy, emerald
- Composition: Symmetrical, centered, balanced
- Style: 1920s glamour meets modern
- Details: Ornate, geometric patterns, metallic

**Prompt Elements:**
```
art deco luxury aesthetic, geometric patterns,
gold and black color palette, symmetrical composition,
dramatic sculptural lighting, 1920s glamour style,
metallic accents, ornate details, premium luxury photography,
high contrast, sharp focus, editorial luxury magazine,
Great Gatsby aesthetic, elegant and sophisticated,
--ar 2:3 --stylize 200
```

### Brutalist Raw
**When to use:** Architecture, modern art, bold statements

**Visual Elements:**
- Background: Concrete, raw materials, industrial
- Lighting: Harsh, unforgiving, creates stark contrast
- Colors: Monochrome, concrete gray, stark blacks
- Composition: Bold, architectural, geometric
- Style: Raw, unpolished, structural
- Mood: Industrial, strong, unapologetic

**Prompt Elements:**
```
brutalist aesthetic, raw concrete textures,
harsh directional lighting, stark high contrast,
monochromatic color palette, geometric composition,
industrial architecture, minimalist brutalism,
unpolished raw materials, structural photography,
contemporary architectural photography style,
bold and unapologetic, modernist design,
--ar 16:9 --stylize 100
```

### Soft Pastel Dream
**When to use:** Beauty, wellness, soft products, feminine brands

**Visual Elements:**
- Background: Soft colors, gradients, or clean white
- Lighting: Soft, diffused, glowing, ethereal
- Colors: Pastels (pink, lavender, mint, peach, baby blue)
- Composition: Gentle, flowing, soft focus
- Style: Dreamy, ethereal, delicate
- Mood: Calm, soothing, gentle

**Prompt Elements:**
```
soft pastel aesthetic, dreamy ethereal lighting,
gentle diffused glow, pastel color palette (pink, lavender, mint),
soft focus background, delicate composition,
ethereal and dreamlike, beauty photography style,
gentle and feminine, soft gradients,
glossy magazine aesthetic, calming peaceful mood,
--ar 4:5 --stylize 200
```

---

## Lighting Patterns Library

### Natural Lighting

**Golden Hour (Sunrise/Sunset)**
- Time: 1 hour after sunrise or before sunset
- Quality: Warm, soft, directional
- Color: Orange, golden tones
- Shadows: Long, soft, flattering
- Mood: Romantic, nostalgic, warm
- Prompt: "golden hour lighting, warm sunset glow, soft directional light"

**Blue Hour (Twilight)**
- Time: 30 min before sunrise or after sunset
- Quality: Cool, even, soft
- Color: Blue, purple tones
- Shadows: Minimal
- Mood: Calm, mysterious, cinematic
- Prompt: "blue hour twilight, cool blue tones, even soft lighting"

**Window Light**
- Source: Large window, indirect sunlight
- Quality: Soft, directional, controllable
- Direction: Side or front, never direct back
- Mood: Natural, authentic, flattering
- Prompt: "soft window light, natural indoor lighting, directional from side"

**Overcast/Diffused**
- Condition: Cloudy day, shaded area
- Quality: Even, flat, soft
- Shadows: Minimal or none
- Mood: Neutral, documentary, realistic
- Prompt: "overcast diffused lighting, soft even natural light, minimal shadows"

**Harsh Midday**
- Time: 11am-2pm
- Quality: Hard, direct, strong
- Shadows: Short, harsh, strong contrast
- Mood: Energetic, bold, summery
- Prompt: "harsh midday sun, strong direct sunlight, high contrast shadows"

### Studio Lighting

**Rembrandt Lighting**
- Setup: Key light 45° angle, creates triangle under eye
- Quality: Dramatic, classic, sculptural
- Mood: Artistic, timeless, dramatic
- Prompt: "Rembrandt lighting, classic portrait lighting, dramatic shadows, triangle of light under eye"

**Butterfly Lighting**
- Setup: Key light directly above, creates butterfly shadow under nose
- Quality: Glamorous, beauty, flattering
- Mood: Hollywood, elegant, polished
- Prompt: "butterfly lighting, glamour photography lighting, soft shadows under nose"

**Loop Lighting**
- Setup: Key light 30-45° angle, small nose shadow
- Quality: Natural, flattering, professional
- Mood: Corporate, professional, clean
- Prompt: "loop lighting, professional portrait lighting, subtle nose shadow, clean and flattering"

**Split Lighting**
- Setup: Key light 90° to side, half face lit/half shadow
- Quality: Dramatic, bold, edgy
- Mood: Intense, mysterious, artistic
- Prompt: "split lighting, dramatic side lighting, half face in shadow, high contrast"

**High-Key Lighting**
- Setup: Bright, even, minimal shadows
- Quality: Airy, light, upbeat
- Mood: Happy, positive, clean
- Prompt: "high-key lighting, bright even illumination, minimal shadows, airy and light"

**Low-Key Lighting**
- Setup: Dark, dramatic shadows, minimal fill
- Quality: Moody, dramatic, noir
- Mood: Mysterious, intense, cinematic
- Prompt: "low-key lighting, dramatic shadows, film noir style, moody and dark"

### Colored Lighting

**Neon/Cyberpunk**
- Colors: Pink, purple, cyan, blue
- Quality: Artificial, glowing, vibrant
- Mood: Futuristic, edgy, modern
- Prompt: "neon lighting, colored gels (pink and cyan), cyberpunk aesthetic, glowing neon signs"

**Warm Tungsten**
- Color: Orange, yellow, warm
- Quality: Cozy, intimate, vintage
- Mood: Nostalgic, warm, inviting
- Prompt: "warm tungsten lighting, orange glow, cozy intimate atmosphere, vintage warmth"

**Cool LED**
- Color: Blue, white, cool tones
- Quality: Modern, clean, clinical
- Mood: Tech, modern, professional
- Prompt: "cool LED lighting, blue-white tones, modern clean aesthetic, tech environment"

---

## Composition Patterns Library

### Classic Compositions

**Rule of Thirds**
- Description: Divide frame into 9 equal parts, place subject on intersections
- Effect: Balanced, professional, visually pleasing
- Use: General purpose, safe choice
- Prompt: "rule of thirds composition, subject on intersection point, balanced framing"

**Center Composition**
- Description: Subject directly in center of frame
- Effect: Bold, simple, impactful
- Use: Symmetry, minimalism, direct statements
- Prompt: "centered composition, symmetrical framing, subject in middle of frame"

**Leading Lines**
- Description: Lines in image lead eye to subject
- Effect: Dynamic, guides attention, depth
- Use: Storytelling, architectural, landscapes
- Prompt: "leading lines composition, diagonal lines guiding to subject, dynamic perspective"

**Frame Within Frame**
- Description: Use elements to create frame around subject
- Effect: Focused attention, depth, artistic
- Use: Portraits, creative shots, storytelling
- Prompt: "frame within frame composition, natural framing elements, focused attention on subject"

### Dynamic Compositions

**Diagonal/Dutch Tilt**
- Description: Horizon line on diagonal, tilted camera
- Effect: Energy, tension, edgy
- Use: Action, modern, unconventional
- Prompt: "dutch angle composition, tilted perspective, dynamic diagonal energy"

**Asymmetrical Balance**
- Description: Off-center but visually balanced
- Effect: Modern, interesting, artistic
- Use: Creative work, breaking conventions
- Prompt: "asymmetrical composition, off-center balance, modern artistic framing"

**Negative Space**
- Description: Large empty areas around subject
- Effect: Minimalist, focus, breathing room
- Use: Minimalism, emphasis, clean aesthetic
- Prompt: "negative space composition, subject isolated, generous empty space, minimalist framing"

**Layered Depth**
- Description: Foreground, subject, background layers
- Effect: Depth, immersive, professional
- Use: Cinematic, storytelling, premium
- Prompt: "layered composition, foreground middle ground background, depth and dimension"

---

## Color Theory Application

### Color Combinations That Work

**Complementary (High Contrast)**
- Pairs: Blue + Orange, Red + Green, Purple + Yellow
- Effect: High energy, attention-grabbing, bold
- Use: Ads, social media, statements
- Prompt: "complementary color scheme, blue and orange contrast, vibrant color palette"

**Analogous (Harmonious)**
- Pairs: Blue + Green + Cyan, Red + Orange + Yellow
- Effect: Harmonious, pleasing, natural
- Use: Lifestyle, natural products, calm
- Prompt: "analogous color palette, harmonious blue green cyan tones, natural color flow"

**Monochromatic (Sophisticated)**
- Range: Single color, varying shades/tones
- Effect: Sophisticated, cohesive, elegant
- Use: Luxury, minimalism, professional
- Prompt: "monochromatic color scheme, shades of blue, sophisticated single-color palette"

**Triadic (Balanced Bold)**
- Three: Evenly spaced on color wheel
- Effect: Vibrant, balanced, playful
- Use: Creative, youth, energetic brands
- Prompt: "triadic color scheme, balanced three-color palette, vibrant and playful"

### Color Psychology

**Red:** Energy, passion, urgency, excitement, danger
**Blue:** Trust, calm, professional, tech, stability
**Yellow:** Optimism, happiness, attention, warning
**Green:** Nature, growth, health, sustainability, calm
**Purple:** Luxury, creativity, royalty, wisdom
**Orange:** Friendly, energetic, affordable, fun
**Pink:** Feminine, playful, romantic, youthful
**Black:** Luxury, sophistication, power, modern
**White:** Clean, pure, minimal, modern, spacious
**Gray:** Neutral, professional, timeless, balanced

---

## Camera Angle Psychology

**Eye-Level:** Neutral, relatable, equal footing
**Low-Angle (Looking Up):** Powerful, dominant, heroic, confident
**High-Angle (Looking Down):** Vulnerable, small, approachable, cute
**Bird's Eye:** Overview, organized, complete picture
**Worm's Eye:** Dramatic, imposing, architectural
**Over-Shoulder:** Perspective, storytelling, immersive
**Close-Up:** Intimate, emotional, detail-focused
**Extreme Close-Up:** Intense, dramatic, abstract
**Wide Shot:** Context, environment, establishing
**Dutch Angle:** Tension, disorientation, edgy

---

## Lens Choice Impact

**Wide (24mm or less):**
- Effect: Distortion, expansive, environmental
- Use: Landscapes, architecture, context
- Prompt: "shot with 24mm wide angle lens, expansive field of view"

**Standard (35-50mm):**
- Effect: Natural, human eye perspective
- Use: Documentary, lifestyle, versatile
- Prompt: "shot with 50mm lens, natural perspective"

**Portrait (85mm):**
- Effect: Compression, flattering, separation
- Use: Portraits, professional headshots
- Prompt: "shot with 85mm portrait lens, natural compression"

**Telephoto (100mm+):**
- Effect: Strong compression, isolated subject
- Use: Sports, wildlife, dramatic portraits
- Prompt: "shot with 135mm telephoto lens, compressed perspective"

**Macro:**
- Effect: Extreme detail, shallow depth
- Use: Product, nature, textures
- Prompt: "macro photography, extreme close-up, shallow depth of field"

---

This reference should be loaded when user needs specific aesthetic direction or visual style guidance for media generation.
