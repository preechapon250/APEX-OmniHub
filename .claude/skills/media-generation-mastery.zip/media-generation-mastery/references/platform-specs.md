# Platform Specifications & Best Practices

Complete technical specifications and analytics-backed best practices for all major platforms.

## Instagram

### Technical Specs
**Feed Posts:**
- Aspect ratios: 1:1 (square), 4:5 (portrait), 1.91:1 (landscape)
- Recommended: 1080x1080 (1:1) or 1080x1350 (4:5)
- Max file size: 30MB (photo), 4GB (video)
- Video length: 3-60 seconds
- Format: JPG, PNG, MP4, MOV

**Stories:**
- Aspect ratio: 9:16 (vertical)
- Resolution: 1080x1920
- Safe zones: Top 250px, bottom 250px (avoid text/important content)
- Max file size: 30MB (photo), 4GB (video)
- Video length: Up to 60 seconds (15 sec recommended)
- Format: JPG, PNG, MP4, MOV

**Reels:**
- Aspect ratio: 9:16 (vertical)
- Resolution: 1080x1920
- Max length: 90 seconds (15-30 optimal for reach)
- Max file size: 4GB
- Format: MP4, MOV
- Audio: Required for maximum reach

**Carousel:**
- Up to 10 images/videos per post
- Same aspect ratio requirements as feed
- Swipe-through format

### Analytics Best Practices
- First 3 seconds critical for Reels (80% drop-off if no hook)
- Faces in thumbnail increase engagement 38%
- Captions increase watch time 16%
- 3-5 hashtags optimal (vs 30 max)
- Post times: 9am, 12pm, 7pm local time (highest engagement)
- Consistency matters: 3-7 posts/week maintains algorithm favor

---

## TikTok

### Technical Specs
- Aspect ratio: 9:16 (vertical) ONLY
- Resolution: 1080x1920 (minimum 720x1280)
- Max length: 10 minutes (60 sec optimal for FYP)
- Max file size: 4GB (iOS), 72MB (Android)
- Format: MP4, MOV
- Audio: Critical for discoverability

### Analytics Best Practices
- Hook in 0.3 seconds (99% scroll if missed)
- Fast cuts every 1-2 seconds maintain attention
- Text captions increase completion 67%
- Trending sounds boost discovery 5-10x
- Post times: 6am, 10am, 7pm local time
- Loop-optimized endings increase replay rate
- Comment engagement signals boost FYP placement
- 3-5 hashtags including 1 trending, 1 niche, 1 branded

---

## YouTube

### Technical Specs
**Long-form Video:**
- Aspect ratio: 16:9 (horizontal)
- Resolution: 1920x1080 minimum (4K preferred for premium content)
- Max file size: 256GB or 12 hours
- Format: MP4, MOV, AVI, WMV, FLV, 3GPP, WebM
- Thumbnail: 1280x720, under 2MB, JPG/PNG

**Shorts:**
- Aspect ratio: 9:16 (vertical)
- Resolution: 1080x1920
- Max length: 60 seconds
- Max file size: Same as long-form
- Format: MP4, MOV

### Analytics Best Practices
**Long-form:**
- First 8 seconds determine 70% of retention
- Pattern breaks every 30 seconds maintain watch time
- Thumbnail + title = 90% of click decision
- Faces showing strong emotion in thumbnail increase CTR 154%
- Text in thumbnail must be readable at small size (3-5 words max)
- Post times: 2pm, 6pm local time (desktop peaks)
- 8-15 minute videos optimal for ad revenue
- End screens increase session time (algorithm boost)

**Shorts:**
- Hook in 1 second (shorts feed moves fast)
- Loop back to beginning (increases views/completion)
- No mid-roll ads = focus on watch time over length
- Post 3-5 shorts/day for maximum shorts feed presence

---

## LinkedIn

### Technical Specs
**Feed Posts:**
- Image aspect ratios: 1.91:1 (1200x628) or 1:1 (1200x1200)
- Video aspect ratios: 16:9, 1:1, 9:16, or 2.4:1
- Max file size: 5MB (image), 5GB (video)
- Video length: 3 seconds - 30 minutes
- Format: JPG, PNG, GIF, MP4, MOV

**Articles:**
- Header image: 1200x627
- In-article images: 1200x900 recommended

### Analytics Best Practices
- Video native uploads get 5x more engagement than links
- First 3 seconds establish credibility (professional quality critical)
- Posts 1300 characters get most engagement (long-form performs)
- Images with people get 2x engagement
- Post times: Tuesday-Thursday, 8am, 12pm, 5pm
- Personal posts outperform company posts 5:1
- Thoughtful commentary > promotional content
- Asking questions increases comments 3x

---

## Twitter/X

### Technical Specs
- Images: 16:9 (1200x675) or 1:1 (1200x1200)
- Video: 16:9 or 1:1, max 512MB (mobile), 2GB (web)
- Video length: 2 minutes 20 seconds (verified: 60 min)
- GIF: 5MB max
- Format: JPG, PNG, GIF, MP4, MOV

### Analytics Best Practices
- First 2 seconds critical (fast scroll environment)
- Text overlays essential (most watch without sound)
- Threads perform better than single tweets
- Images get 150% more retweets than text-only
- Videos get 10x more engagement than photos
- Post times: 9am, 12pm, 3pm local time
- Hashtags: 1-2 max (more reduces engagement)
- Asking for retweets increases retweets 23x

---

## Facebook

### Technical Specs
**Feed Posts:**
- Images: 1200x630 (link), 1080x1080 (standard)
- Video: 1080x1080 (square), 1920x1080 (landscape), 1080x1920 (vertical)
- Max file size: 4GB
- Video length: 1 second - 240 minutes
- Format: JPG, PNG, GIF, MP4, MOV

**Stories:**
- Aspect ratio: 9:16 (1080x1920)
- Max file size: 30MB
- Video length: Up to 20 seconds

### Analytics Best Practices
- Native video uploads get 10x more reach than YouTube links
- First 3 seconds determine 65% of 30-second completion
- Captions increase video views 12%
- Square videos get 35% more engagement than landscape
- Post times: 1pm, 3pm local time (highest engagement)
- Emotional content gets 2x shares
- Facebook Watch prioritizes 3+ minute videos
- Group content gets higher reach than page posts

---

## Pinterest

### Technical Specs
**Standard Pins:**
- Aspect ratio: 2:3 (1000x1500 recommended)
- Max file size: 20MB
- Format: JPG, PNG
- Video: Up to 15 minutes, 2GB max

**Idea Pins:**
- Aspect ratio: 9:16 (1080x1920)
- Up to 20 pages per pin
- Video: 60 seconds per page max

### Analytics Best Practices
- Vertical images get 60% more engagement
- Text overlays increase saves 25%
- Bright, high-contrast images perform best
- How-to and DIY content gets most saves
- Post times: 8pm-11pm (highest engagement)
- Seasonal content should be pinned 30-45 days early
- Multiple pins from same content increase reach
- Rich pins (with metadata) get 4x more clicks

---

## Snapchat

### Technical Specs
**Snaps/Stories:**
- Aspect ratio: 9:16 (1080x1920)
- Max video length: 60 seconds
- Format: MP4, MOV

**Spotlight:**
- Aspect ratio: 9:16
- Length: Up to 60 seconds
- Max file size: 1GB

### Analytics Best Practices
- Vertical full-screen content only
- No external links (internal engagement focus)
- Young demographic (13-24 primary)
- Filters and lenses increase engagement
- Post frequency: Multiple times daily
- Ephemeral nature = less polished okay

---

## Platform-Specific Content Strategies

### High-Production Platforms (Require Polish)
- **YouTube** - Professional quality expected
- **LinkedIn** - Corporate-grade essential
- **Brand websites** - Flawless execution

### Mid-Production Platforms (Polished but Personality)
- **Instagram Feed** - High quality but authentic
- **Facebook** - Professional but personal
- **Pinterest** - Aspirational quality

### Low-Production Platforms (Authentic > Perfect)
- **TikTok** - Raw authenticity performs better than overproduction
- **Instagram Stories/Reels** - Phone-shot quality acceptable
- **Twitter/X** - Quick, timely matters more than polish
- **Snapchat** - Casual, in-the-moment content

---

## Cross-Platform Adaptation Strategy

Don't just repost the same content everywhere. Adapt:

**Same Core Asset, Platform-Optimized Versions:**
1. **Master Version** (highest quality, longest format)
   - YouTube long-form or Instagram feed post

2. **Platform Adaptations:**
   - YouTube → Cut to 60 sec for Shorts
   - Instagram → 15-30 sec for Reels
   - TikTok → Fast-paced 15-30 sec version
   - LinkedIn → Professional context added
   - Twitter → Key moment clip 30 sec
   - Facebook → Square crop for feed

3. **Format Adjustments Per Platform:**
   - Captions ON by default (TikTok, Instagram, LinkedIn)
   - Audio priority (TikTok, Instagram Reels)
   - Silent-friendly (LinkedIn, Twitter, Facebook feed)

---

## Algorithm Optimization Signals (Universal)

**Platforms reward:**
1. **Watch time / Dwell time** - Keep them engaged
2. **Completion rate** - Deliver full value
3. **Engagement** - Comments > Shares > Saves > Likes
4. **Velocity** - Fast early engagement signals quality
5. **Session time** - Keep them on platform longer
6. **Rewatches** - Strong signal of value
7. **Shares** - Ultimate endorsement

**Platforms punish:**
1. **Quick exits** - Poor content signal
2. **External links** (some platforms) - Keeps users off-platform
3. **Clickbait without delivery** - Promise must match content
4. **Low-quality** - Pixelated, poor audio, bad framing
5. **Reposted content** - Especially watermarked
6. **Engagement bait** - "Comment below," "Tag a friend" 
7. **Spam hashtags** - Excessive or irrelevant

---

## Accessibility Best Practices (All Platforms)

**Required for maximum reach:**
- **Captions/subtitles** on all videos (30% watch without sound)
- **Alt text** on images (screen readers + SEO)
- **High contrast** text overlays (readability)
- **Avoid flashing** content (seizure risk + platform flags)
- **Clear audio** without background noise
- **Readable fonts** at small sizes

---

## File Preparation Checklist

Before uploading ANY content:

✅ Correct aspect ratio for platform
✅ Resolution meets minimum specs
✅ File size under platform limits
✅ Format compatible with platform
✅ Captions/subtitles embedded or uploaded separately
✅ Audio levels normalized (-14 LUFS standard)
✅ Color grading consistent
✅ Branding elements in safe zones
✅ Thumbnail optimized (if applicable)
✅ Metadata prepared (title, description, tags)

---

## Emergency Platform Updates

Platforms change specs regularly. If specs in this document fail:

1. Check platform's official creator resources
2. Test with minimum specs first
3. Validate on multiple devices before large campaigns
4. Monitor analytics for performance drops after platform updates
