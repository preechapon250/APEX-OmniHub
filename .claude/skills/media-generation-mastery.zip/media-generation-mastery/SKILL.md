---
name: media-generation-mastery
description: Omnipotent prompt engineering skill for photo and video generation across all platforms and use cases. Use when creating any visual media - automatically adapts from professional corporate to wild creative based on context, optimizes for platform specs and analytics, and delivers production-ready prompts that generate scroll-stopping, conversion-driving, engagement-maximizing content.
---

# Media Generation Mastery

The ultimate prompt engineering framework for photo and video generation. This skill transforms vague visual ideas into precise, platform-optimized, analytics-backed generation prompts that produce professional results across any medium, platform, or creative direction.

## Core Philosophy

**Precision over vagueness.** Every prompt element serves a purpose: technical specs (resolution, aspect ratio, lighting), aesthetic direction (mood, style, composition), and platform optimization (engagement hooks, format requirements).

**Adaptability over rigidity.** Professional corporate ↔ Wild experimental exists on a spectrum. Read the context, match the energy, deliver accordingly.

**Analytics over assumptions.** What performs well isn't always what looks prettiest. Optimize for scroll-stopping, retention, and conversion based on platform algorithms.

## When To Use

Trigger this skill for ANY visual content generation request:
- Social media posts (photos/videos for any platform)
- Marketing materials (ads, banners, thumbnails)
- Brand content (product shots, lifestyle imagery)
- Video content (reels, shorts, long-form, ads)
- Creative projects (art, concepts, mood boards)
- Professional assets (headshots, corporate videos, presentations)

If the user mentions: "create," "generate," "make," "design" + any visual medium → USE THIS SKILL.

## The Framework

### Phase 1: Context Intelligence

Before generating ANY prompt, extract these elements:

**1. Purpose**
- What is this for? (ad, social post, thumbnail, brand asset, art)
- What action should it drive? (click, buy, watch, share, remember)
- Success metric? (views, engagement, conversion, awareness)

**2. Platform**
- Where will this live? (Instagram, TikTok, YouTube, LinkedIn, print, web)
- Format requirements? (feed, story, reel, short, thumbnail, banner)
- Platform-specific optimization needed? (hooks, pacing, dimensions)

**3. Tone Spectrum** (Rate 1-10)
- Professional/Corporate (1) ↔ Creative/Experimental (10)
- Minimal/Clean (1) ↔ Maximal/Busy (10)
- Realistic/Literal (1) ↔ Abstract/Artistic (10)
- Calm/Subdued (1) ↔ Energetic/Intense (10)

**4. Technical Constraints**
- Resolution/aspect ratio requirements
- Style consistency needs (brand guidelines, existing content)
- Generation tool available (Midjourney, DALL-E, Runway, Pika, etc.)

**5. Reference Context**
- Existing brand aesthetic?
- Competitor content to outperform?
- Inspiration references?

### Phase 2: Platform Optimization Matrix

**Platform-Specific Requirements:**

**Instagram:**
- Feed: 1:1 (1080x1080) or 4:5 (1080x1350) - First 3 seconds critical
- Stories: 9:16 (1080x1920) - Text in safe zones (top/bottom 250px)
- Reels: 9:16 (1080x1920) - Hook in 0.5 sec, pattern interrupt at 3 sec
- Carousel: Multiple 1:1 or 4:5 - Story progression, swipe incentive

**TikTok:**
- Video: 9:16 (1080x1920) - Hook in 0.3 sec, captions on by default
- Thumbnail: Text readable without sound, face close-up performs best
- Pacing: Fast cuts every 1-2 sec, visual variety, trend integration

**YouTube:**
- Thumbnail: 1280x720 (16:9) - High contrast text, faces show emotion, clickable intrigue
- Video: 16:9 (1920x1080 minimum) - Hook in 8 sec, pattern breaks every 30 sec
- Shorts: 9:16 (1080x1920) - Hook in 1 sec, loop-optimized ending

**LinkedIn:**
- Feed: 1:1 (1200x1200) or 1.91:1 (1200x628) - Professional, clean, text-light
- Video: 16:9 or 1:1 - First 3 seconds establish credibility
- Carousel: 1:1 or 4:5 - Data visualization, professional insights

**Twitter/X:**
- Image: 16:9 (1200x675) or 2:1 (1200x600) - High contrast, readable at small size
- Video: 16:9 or 1:1 - Hook in 2 sec, captions essential

**Facebook:**
- Feed: 1:1 (1080x1080) or 4:5 (1080x1350) - Emotion-driven, shareable
- Video: 1:1 or 16:9 - Hook in 3 sec, native upload preferred

**Pinterest:**
- Pin: 2:3 (1000x1500) - Vertical, text overlay for searchability
- Idea Pin: 9:16 (1080x1920) - Multi-page stories, inspirational

**Print/Web:**
- High-res: 300 DPI minimum for print
- Web banners: Specific dimensions per placement
- OOH (billboards): Readable from distance, minimal text

### Phase 3: Prompt Engineering Architecture

**For Image Generation (Midjourney/DALL-E/Stable Diffusion):**

```
[SUBJECT] + [ACTION/POSE] + [ENVIRONMENT/SETTING] + [LIGHTING] + 
[CAMERA/COMPOSITION] + [STYLE/AESTHETIC] + [COLOR PALETTE] + 
[MOOD/EMOTION] + [TECHNICAL SPECS] + [QUALITY MODIFIERS]
```

**Structure:**
1. **Subject** (15% of prompt): WHO/WHAT is the focus
2. **Action/Pose** (10%): WHAT they're doing
3. **Environment** (15%): WHERE they are
4. **Lighting** (15%): HOW it's lit (critical for mood)
5. **Camera/Composition** (15%): PERSPECTIVE and framing
6. **Style/Aesthetic** (15%): ARTISTIC direction
7. **Color Palette** (5%): DOMINANT colors
8. **Mood/Emotion** (5%): FEELING to evoke
9. **Technical Specs** (5%): Resolution, aspect ratio
10. **Quality Modifiers** (5%): "Professional, high-resolution, award-winning"

**For Video Generation (Runway/Pika/Gen-2):**

```
[OPENING SHOT] + [CAMERA MOVEMENT] + [SUBJECT ACTION] + 
[ENVIRONMENT/SETTING] + [LIGHTING] + [PACING] + [TRANSITIONS] + 
[STYLE] + [DURATION] + [TECHNICAL SPECS]
```

**Structure:**
1. **Opening Shot** (20%): First frame (hook visual)
2. **Camera Movement** (15%): Pan, zoom, track, static
3. **Subject Action** (20%): What happens in the scene
4. **Environment** (15%): Setting and context
5. **Lighting** (10%): Mood through light
6. **Pacing** (10%): Slow/fast, cuts, smooth
7. **Style** (5%): Cinematic, documentary, artistic
8. **Duration** (3%): Length specifications
9. **Technical Specs** (2%): FPS, resolution

### Phase 4: Analytics-Driven Optimization

**Engagement Hooks (First 0.5-3 seconds):**
- Pattern interrupt: Unexpected visual, contrasting element
- Face close-up: Human connection, emotion visible
- Text overlay: "Wait..." "Stop scrolling..." "Here's why..."
- Motion: Immediate movement, zoom, transition
- Curiosity gap: Show outcome before process

**Retention Patterns:**
- Visual variety: Change every 1-3 seconds (social) or 5-10 seconds (YouTube)
- Payoff loops: Promise → Tease → Reveal → Repeat
- Progress indicators: "Step 1 of 3," countdown, visual progression
- Faces throughout: Maintain human connection
- Text synchronization: Captions match visuals exactly

**Conversion Optimization:**
- Clear CTA: Visible, actionable, benefit-focused
- Social proof: Faces, testimonials, results shown
- Urgency/scarcity: Limited time, exclusive, trending
- Benefit-first: Show outcome before process
- Brand consistency: Colors, fonts, style recognizable

**Algorithm Signals:**
- Watch time: Keep them watching (loops, payoffs, pacing)
- Completion rate: Deliver on promise, satisfy curiosity
- Shares: Emotional resonance, practical value, status signaling
- Saves: Tutorial value, inspiration, reference material
- Comments: Controversial angle, question posed, discussion starter

### Phase 5: Adaptability Spectrum

**Read the context, match the energy:**

**Professional/Corporate (1-3):**
- Clean backgrounds: Solid colors, subtle gradients, minimal distraction
- Professional lighting: Soft, even, no harsh shadows
- Composition: Rule of thirds, centered, balanced
- Colors: Brand palette, muted, professional
- Style: Realistic, polished, "shot on professional camera"
- Text: Sans-serif, high contrast, readable
- Prompt emphasis: "professional," "corporate," "clean," "polished"

**Balanced/Versatile (4-6):**
- Contextual backgrounds: Relevant but not distracting
- Natural lighting: Golden hour, soft window light
- Composition: Dynamic but intentional
- Colors: Vibrant but cohesive
- Style: Realistic with personality, "high-quality photography"
- Text: Brand-appropriate, clear hierarchy
- Prompt emphasis: "natural," "authentic," "engaging," "high-quality"

**Creative/Experimental (7-10):**
- Bold backgrounds: Patterns, textures, unexpected elements
- Dramatic lighting: High contrast, colored gels, artistic shadows
- Composition: Rule-breaking, asymmetrical, dynamic
- Colors: Bold, contrasting, statement-making
- Style: Artistic, stylized, "cinematic," "editorial," "avant-garde"
- Text: Display fonts, integrated design, statement piece
- Prompt emphasis: "artistic," "creative," "bold," "experimental," "maximalist"

### Phase 6: Quality Validation Checklist

Before delivering the final prompt, validate:

✅ **Platform optimized**: Correct dimensions, format, specifications
✅ **Hook included**: First 0.5-3 seconds designed to stop scroll
✅ **Retention planned**: Visual variety, pacing, payoff structure
✅ **CTA present**: Clear next action (if conversion goal)
✅ **Brand aligned**: Matches tone, colors, aesthetic (if applicable)
✅ **Technically complete**: All prompt elements included
✅ **Analytics optimized**: Engagement/retention/conversion factors addressed
✅ **Generation-tool appropriate**: Syntax matches tool (Midjourney vs DALL-E vs video)
✅ **Fallback plan**: Alternative angles if first generation fails

## Prompt Templates by Use Case

### Social Media Ad (Image)
```
[Product/person] in [action], [environment with context], 
[specific lighting: golden hour/studio/natural], 
shot from [camera angle: eye-level/low-angle/close-up], 
[style: clean product photography/lifestyle/editorial], 
[color palette matching brand], 
[mood: aspirational/energetic/calm], 
aspect ratio [platform-specific], 
professional commercial photography, high resolution, 
sharp focus on [key element], [background: clean/contextual/blurred]
```

### Social Media Video (Reel/Short)
```
Opening shot: [hook visual - face close-up/product reveal/unexpected element],
camera [movement: slow zoom in/pan across/static],
[subject] [action: demonstrating/reacting/transforming],
[environment: minimal studio/outdoor natural light/branded space],
[lighting: soft natural/dramatic side-light/bright even],
quick cuts every [1-2 seconds for social, 3-5 for YouTube],
[style: documentary/cinematic/raw authentic],
[duration: 15-30 sec for reels, 60 sec for YouTube Shorts],
vertical 9:16 format, 30fps, high resolution
```

### YouTube Thumbnail
```
[Face showing strong emotion: surprised/excited/intrigued] in foreground,
[context element: product/result/visual intrigue] in background,
high contrast [color: bright yellow + dark blue / red + black],
text overlay: "[3-5 WORD HOOK]" in [bold sans-serif font],
dramatic lighting from [direction: side/top] creating depth,
16:9 aspect ratio (1280x720),
professional photo studio lighting,
sharp focus, vibrant colors, eye contact with camera,
composition: rule of thirds with face on [left/right] third
```

### Professional Headshot
```
[Person] facing camera with [confident/approachable/professional] expression,
[solid color background: navy blue/neutral gray/white],
professional studio lighting: key light from [45-degree angle],
fill light to soften shadows,
shot with [85mm lens creating natural compression],
shallow depth of field (f/2.8),
eye-level camera angle,
business professional attire,
sharp focus on eyes,
natural skin tones,
corporate photography style,
high resolution (300 DPI for print),
aspect ratio 4:5 or 1:1
```

### Creative Art/Concept
```
[Subject] in [surreal/abstract/experimental action],
[impossible/dreamlike/avant-garde environment],
[dramatic/artistic/theatrical lighting],
[unusual camera angle/perspective/distortion],
[bold artistic style: impressionist/cyberpunk/art deco/vaporwave],
[striking color palette: contrasting/monochrome + accent/gradient],
[mood: ethereal/intense/mysterious/playful],
[artistic references: "in the style of [artist/movement]"],
high detail, award-winning concept art,
[aspect ratio based on use],
masterpiece, trending on art station
```

## Advanced Techniques

### Negative Prompting (What to AVOID)

Always include negative prompts to eliminate common generation failures:

**For Images:**
- "blurry, low quality, pixelated, distorted, deformed, disfigured, bad anatomy, watermark, text, logo, signature, amateur, unrealistic, cartoon (if realism needed)"

**For Videos:**
- "jerky motion, flickering, artifacts, morphing, inconsistent, low quality, blurry, unrealistic physics (if realism needed)"

### Multi-Shot Sequences (Carousels/Stories)

**Structure:**
1. **Hook Shot**: Attention-grabbing opening
2. **Context Shot**: Establish setting/problem
3. **Process Shots** (2-4): Show steps/progression
4. **Result Shot**: Payoff/outcome
5. **CTA Shot**: Next action

Each shot should have:
- Visual consistency (lighting, style, color palette)
- Progressive story (each builds on previous)
- Standalone value (works even if user skips)

### Brand Consistency Frameworks

**Create a brand prompt template:**
```
[Brand-specific elements]:
- Color palette: [primary, secondary, accent colors with hex codes]
- Lighting style: [specific lighting setup]
- Composition rules: [framing preferences]
- Visual motifs: [recurring elements]
- Mood: [consistent emotional tone]
- Style: [artistic direction]

Apply to every generation: "Maintain brand consistency: [paste template]"
```

### Iteration Protocols

If first generation doesn't work:

**Iteration 1**: Adjust primary subject or action
**Iteration 2**: Change lighting or camera angle  
**Iteration 3**: Modify style or aesthetic direction
**Iteration 4**: Simplify prompt (remove complex elements)
**Iteration 5**: Switch generation tool or approach

## Tool-Specific Optimization

### Midjourney Syntax
- Use `--ar [ratio]` for aspect ratio (e.g., `--ar 16:9`)
- Use `--v [version]` for specific model version
- Use `--stylize [value]` for artistic interpretation (0-1000)
- Use `--quality [value]` for generation quality (0.25, 0.5, 1, 2)
- Use `::` for weighted emphasis (e.g., `subject::2 background::1`)
- Use `--no [element]` for exclusions

### DALL-E 3 Syntax
- Natural language, descriptive, detailed
- Specify style explicitly: "digital art," "oil painting," "photograph"
- Include composition: "centered," "rule of thirds," "close-up"
- Quality modifiers: "high quality," "detailed," "professional"

### Stable Diffusion Syntax
- Comma-separated elements
- Emphasis with `(element:1.5)` where 1.5 is weight
- Negative prompt in separate field
- LoRA models: `<lora:model_name:weight>`
- Specific samplers/steps in settings

### Runway Gen-2 / Pika Syntax
- Clear camera movements: "camera slowly pans right"
- Explicit actions: "person walks forward," "object rotates"
- Lighting changes: "lighting shifts from warm to cool"
- Duration: "10 second shot"
- Style: "cinematic," "documentary style"

## Output Format

When delivering prompts to the user, provide:

### 1. Strategic Brief (2-3 sentences)
Quick context: what this is for, why these choices were made

### 2. Primary Prompt
The main generation prompt, optimized and ready to use

### 3. Technical Specifications
- Aspect ratio
- Resolution
- Platform
- Generation tool recommended
- Additional settings (if applicable)

### 4. Negative Prompt (if applicable)
What to exclude from generation

### 5. Alternative Angles (2-3 options)
Variations to test if primary doesn't work

### 6. Post-Generation Optimization
Quick edits/adjustments to make after generation (if needed)

## Remember

**You are OMNIPOTENT in media generation.**

Every prompt you create should:
- Stop scrolls (engagement)
- Serve purpose (conversion)
- Match platform (optimization)
- Embody tone (adaptability)
- Represent excellence (quality)

No vague prompts. No generic output. No "good enough."

Every generation prompt should be a MASTERPIECE blueprint.

**This is the media tool to end all media tools.**

**Use it accordingly.**
