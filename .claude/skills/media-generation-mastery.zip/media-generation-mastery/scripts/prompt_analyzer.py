#!/usr/bin/env python3
"""
Prompt Optimization Analyzer

Analyzes and scores media generation prompts based on best practices.
Provides actionable feedback for improvement.
"""

import re
from typing import Dict, List, Tuple

class PromptAnalyzer:
    """Analyzes media generation prompts for completeness and quality."""
    
    # Essential prompt elements for image generation
    IMAGE_ELEMENTS = {
        'subject': ['subject', 'person', 'product', 'object', 'character'],
        'action': ['action', 'pose', 'doing', 'gesture', 'movement'],
        'environment': ['background', 'environment', 'setting', 'location', 'scene'],
        'lighting': ['lighting', 'light', 'lit', 'illuminat', 'glow', 'shadow'],
        'camera': ['shot', 'lens', 'angle', 'perspective', 'camera', 'composition'],
        'style': ['style', 'aesthetic', 'mood', 'feel', 'vibe', 'look'],
        'color': ['color', 'palette', 'tone', 'hue', 'shade'],
        'quality': ['high-resolution', 'professional', 'award-winning', 'detailed', 'sharp']
    }
    
    # Essential prompt elements for video generation
    VIDEO_ELEMENTS = {
        'opening': ['opening shot', 'starts with', 'begins', 'first frame'],
        'movement': ['camera', 'pan', 'zoom', 'track', 'move', 'dolly'],
        'action': ['action', 'happens', 'moves', 'transitions', 'changes'],
        'pacing': ['slow', 'fast', 'quick', 'gradual', 'smooth', 'cut'],
        'duration': ['second', 'seconds', 'length', 'duration', 'time'],
        'style': ['cinematic', 'documentary', 'style', 'aesthetic']
    }
    
    # Platform specifications
    PLATFORM_SPECS = {
        'instagram_feed': {'ratios': ['1:1', '4:5'], 'res': '1080x1080'},
        'instagram_story': {'ratios': ['9:16'], 'res': '1080x1920'},
        'instagram_reel': {'ratios': ['9:16'], 'res': '1080x1920'},
        'tiktok': {'ratios': ['9:16'], 'res': '1080x1920'},
        'youtube_video': {'ratios': ['16:9'], 'res': '1920x1080'},
        'youtube_short': {'ratios': ['9:16'], 'res': '1080x1920'},
        'youtube_thumbnail': {'ratios': ['16:9'], 'res': '1280x720'},
        'linkedin': {'ratios': ['1:1', '1.91:1'], 'res': '1200x1200'},
        'twitter': {'ratios': ['16:9', '1:1'], 'res': '1200x675'},
        'pinterest': {'ratios': ['2:3'], 'res': '1000x1500'}
    }
    
    def analyze_prompt(self, prompt: str, media_type: str = 'image', 
                      platform: str = None) -> Dict:
        """
        Analyzes a prompt and returns quality score with suggestions.
        
        Args:
            prompt: The generation prompt to analyze
            media_type: Either 'image' or 'video'
            platform: Optional platform name for spec checking
            
        Returns:
            Dictionary with score, found elements, missing elements, and suggestions
        """
        prompt_lower = prompt.lower()
        
        if media_type == 'image':
            elements = self.IMAGE_ELEMENTS
        else:
            elements = self.VIDEO_ELEMENTS
        
        found = {}
        missing = []
        
        # Check for each element category
        for category, keywords in elements.items():
            if any(keyword in prompt_lower for keyword in keywords):
                found[category] = True
            else:
                missing.append(category)
        
        # Calculate score (out of 100)
        total_elements = len(elements)
        found_elements = len(found)
        base_score = (found_elements / total_elements) * 100
        
        # Bonus points
        bonus = 0
        
        # Check for technical specs
        if any(ratio in prompt for ratio in ['16:9', '9:16', '1:1', '4:5', '2:3']):
            bonus += 5
        
        # Check for negative prompts
        if 'not ' in prompt_lower or 'without ' in prompt_lower or 'avoid ' in prompt_lower:
            bonus += 5
        
        # Check for quality modifiers
        quality_words = ['professional', 'high-resolution', 'award-winning', 
                        'detailed', 'sharp', 'crisp', 'premium']
        if any(word in prompt_lower for word in quality_words):
            bonus += 5
        
        # Check for platform optimization
        if platform and platform in self.PLATFORM_SPECS:
            spec = self.PLATFORM_SPECS[platform]
            if any(ratio in prompt for ratio in spec['ratios']):
                bonus += 10
        
        final_score = min(100, base_score + bonus)
        
        # Generate suggestions
        suggestions = self._generate_suggestions(missing, prompt, platform)
        
        return {
            'score': round(final_score, 1),
            'found_elements': list(found.keys()),
            'missing_elements': missing,
            'suggestions': suggestions,
            'word_count': len(prompt.split())
        }
    
    def _generate_suggestions(self, missing: List[str], prompt: str, 
                            platform: str = None) -> List[str]:
        """Generates actionable improvement suggestions."""
        suggestions = []
        
        # Element-specific suggestions
        element_suggestions = {
            'subject': "Add clear subject description (WHO/WHAT is the focus)",
            'action': "Specify action or pose (WHAT is the subject doing)",
            'environment': "Describe environment/setting (WHERE is this happening)",
            'lighting': "Define lighting setup (HOW is it lit)",
            'camera': "Specify camera angle/lens (HOW is it shot)",
            'style': "Add aesthetic/style direction (WHAT is the vibe)",
            'color': "Include color palette specification",
            'quality': "Add quality modifiers (professional, high-resolution, etc.)",
            'opening': "Describe opening shot (first frame hook)",
            'movement': "Specify camera movement (pan, zoom, static)",
            'pacing': "Define pacing (slow/fast, cut timing)",
            'duration': "Include duration specification"
        }
        
        for element in missing:
            if element in element_suggestions:
                suggestions.append(element_suggestions[element])
        
        # Platform-specific suggestions
        if platform and platform in self.PLATFORM_SPECS:
            spec = self.PLATFORM_SPECS[platform]
            if not any(ratio in prompt for ratio in spec['ratios']):
                suggestions.append(
                    f"Add aspect ratio for {platform}: {', '.join(spec['ratios'])}"
                )
        
        # Length suggestions
        word_count = len(prompt.split())
        if word_count < 20:
            suggestions.append("Prompt is too short - add more descriptive elements (aim for 30-60 words)")
        elif word_count > 100:
            suggestions.append("Prompt might be too long - focus on essential elements (aim for 30-60 words)")
        
        return suggestions
    
    def compare_prompts(self, prompt1: str, prompt2: str, 
                       media_type: str = 'image') -> Dict:
        """Compares two prompts and recommends which is better."""
        analysis1 = self.analyze_prompt(prompt1, media_type)
        analysis2 = self.analyze_prompt(prompt2, media_type)
        
        return {
            'prompt1': analysis1,
            'prompt2': analysis2,
            'recommended': 1 if analysis1['score'] > analysis2['score'] else 2,
            'score_difference': abs(analysis1['score'] - analysis2['score'])
        }


def analyze_prompt_quality(prompt: str, media_type: str = 'image', 
                          platform: str = None) -> None:
    """
    Command-line interface for prompt analysis.
    
    Args:
        prompt: The generation prompt to analyze
        media_type: Either 'image' or 'video'
        platform: Optional platform name
    """
    analyzer = PromptAnalyzer()
    result = analyzer.analyze_prompt(prompt, media_type, platform)
    
    print("\n" + "="*60)
    print("PROMPT QUALITY ANALYSIS")
    print("="*60)
    print(f"\nPrompt: {prompt[:100]}{'...' if len(prompt) > 100 else ''}")
    print(f"\nOverall Score: {result['score']}/100")
    
    # Score interpretation
    if result['score'] >= 90:
        quality = "EXCELLENT - Ready for generation"
    elif result['score'] >= 75:
        quality = "GOOD - Minor improvements possible"
    elif result['score'] >= 60:
        quality = "FAIR - Several improvements needed"
    else:
        quality = "POOR - Significant improvements required"
    
    print(f"Quality: {quality}")
    
    print(f"\nWord Count: {result['word_count']}")
    print(f"  (Optimal: 30-60 words for most platforms)")
    
    print(f"\n✅ Found Elements ({len(result['found_elements'])}):")
    for element in result['found_elements']:
        print(f"  • {element}")
    
    if result['missing_elements']:
        print(f"\n❌ Missing Elements ({len(result['missing_elements'])}):")
        for element in result['missing_elements']:
            print(f"  • {element}")
    
    if result['suggestions']:
        print(f"\n💡 Suggestions for Improvement:")
        for i, suggestion in enumerate(result['suggestions'], 1):
            print(f"  {i}. {suggestion}")
    
    print("\n" + "="*60 + "\n")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) < 2:
        print("Usage: python prompt_analyzer.py \"<your prompt>\" [media_type] [platform]")
        print("\nExample:")
        print('  python prompt_analyzer.py "professional headshot, studio lighting" image linkedin')
        sys.exit(1)
    
    prompt = sys.argv[1]
    media_type = sys.argv[2] if len(sys.argv) > 2 else 'image'
    platform = sys.argv[3] if len(sys.argv) > 3 else None
    
    analyze_prompt_quality(prompt, media_type, platform)
