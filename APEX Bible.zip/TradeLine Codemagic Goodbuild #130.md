Preparing build machine
36s



== User-defined environment variables ==
APP_STORE_CONNECT_ISSUER_ID=HIDDEN (hash: c1d00a44)
APP_STORE_CONNECT_KEY_IDENTIFIER=HIDDEN (hash: 0e920282)
APP_STORE_CONNECT_PRIVATE_KEY=HIDDEN (hash: eb2b4c5b)
APP_STORE_ID=$APP_STORE_ID
BUNDLE_ID=com.apex.tradeline
CERTIFICATE_PRIVATE_KEY=HIDDEN (hash: 9aa01fa6)
TEAM_ID=NWGUYF42KW
XCODE_SCHEME=App
XCODE_WORKSPACE=ios/App/App.xcworkspace

== Use Xcode 16.4 ==
> xcodebuild -version
Xcode 16.4
Build version 16F6

== Use default version of CocoaPods ==
> gem list '^cocoapods$' --no-verbose
cocoapods (1.16.2)

== Use Java version 17 ==
> java -version
openjdk version "17.0.15" 2025-04-15 LTS
OpenJDK Runtime Environment Zulu17.58+21-CA (build 17.0.15+6-LTS)
OpenJDK 64-Bit Server VM Zulu17.58+21-CA (build 17.0.15+6-LTS, mixed mode, sharing)

== Use Node version 20.19.0 ==
> n 20.19.0

> node --version
v20.19.0

== Use npm version 10 ==
> npm install -g npm@10

> npm --version
10.9.4

== Codemagic CLI tools ==
> codemagic-cli-tools version
codemagic-cli-tools 0.62.1

Fetching app sources
5s




== Cloning repository https://github.com/Apex-Business-Apps/TradeLine247 for main ==
> /usr/bin/git clone --progress --branch main --depth 50 https://Apex-Business-Apps@github.com/Apex-Business-Apps/TradeLine247 /Users/builder/clone
Cloning into '/Users/builder/clone'...
remote: Enumerating objects: 2039, done.        
remote: Counting objects:   0% (1/2039)        
remote: Counting objects:   1% (21/2039)        
remote: Counting objects:   2% (41/2039)        
remote: Counting objects:   3% (62/2039)        
remote: Counting objects:   4% (82/2039)        
remote: Counting objects:   5% (102/2039)        
remote: Counting objects:   6% (123/2039)        
remote: Counting objects:   7% (143/2039)        
remote: Counting objects:   8% (164/2039)        
remote: Counting objects:   9% (184/2039)        
remote: Counting objects:  10% (204/2039)        
remote: Counting objects:  11% (225/2039)        
remote: Counting objects:  12% (245/2039)        
remote: Counting objects:  13% (266/2039)        
remote: Counting objects:  14% (286/2039)        
remote: Counting objects:  15% (306/2039)        
remote: Counting objects:  16% (327/2039)        
remote: Counting objects:  17% (347/2039)        
remote: Counting objects:  18% (368/2039)        
remote: Counting objects:  19% (388/2039)        
remote: Counting objects:  20% (408/2039)        
remote: Counting objects:  21% (429/2039)        
remote: Counting objects:  22% (449/2039)        
remote: Counting objects:  23% (469/2039)        
remote: Counting objects:  24% (490/2039)        
remote: Counting objects:  25% (510/2039)        
remote: Counting objects:  26% (531/2039)        
remote: Counting objects:  27% (551/2039)        
remote: Counting objects:  28% (571/2039)        
remote: Counting objects:  29% (592/2039)        
remote: Counting objects:  30% (612/2039)        
remote: Counting objects:  31% (633/2039)        
remote: Counting objects:  32% (653/2039)        
remote: Counting objects:  33% (673/2039)        
remote: Counting objects:  34% (694/2039)        
remote: Counting objects:  35% (714/2039)        
remote: Counting objects:  36% (735/2039)        
remote: Counting objects:  37% (755/2039)        
remote: Counting objects:  38% (775/2039)        
remote: Counting objects:  39% (796/2039)        
remote: Counting objects:  40% (816/2039)        
remote: Counting objects:  41% (836/2039)        
remote: Counting objects:  42% (857/2039)        
remote: Counting objects:  43% (877/2039)        
remote: Counting objects:  44% (898/2039)        
remote: Counting objects:  45% (918/2039)        
remote: Counting objects:  46% (938/2039)        
remote: Counting objects:  47% (959/2039)        
remote: Counting objects:  48% (979/2039)        
remote: Counting objects:  49% (1000/2039)        
remote: Counting objects:  50% (1020/2039)        
remote: Counting objects:  51% (1040/2039)        
remote: Counting objects:  52% (1061/2039)        
remote: Counting objects:  53% (1081/2039)        
remote: Counting objects:  54% (1102/2039)        
remote: Counting objects:  55% (1122/2039)        
remote: Counting objects:  56% (1142/2039)        
remote: Counting objects:  57% (1163/2039)        
remote: Counting objects:  58% (1183/2039)        
remote: Counting objects:  59% (1204/2039)        
remote: Counting objects:  60% (1224/2039)        
remote: Counting objects:  61% (1244/2039)        
remote: Counting objects:  62% (1265/2039)        
remote: Counting objects:  63% (1285/2039)        
remote: Counting objects:  64% (1305/2039)        
remote: Counting objects:  65% (1326/2039)        
remote: Counting objects:  66% (1346/2039)        
remote: Counting objects:  67% (1367/2039)        
remote: Counting objects:  68% (1387/2039)        
remote: Counting objects:  69% (1407/2039)        
remote: Counting objects:  70% (1428/2039)        
remote: Counting objects:  71% (1448/2039)        
remote: Counting objects:  72% (1469/2039)        
remote: Counting objects:  73% (1489/2039)        
remote: Counting objects:  74% (1509/2039)        
remote: Counting objects:  75% (1530/2039)        
remote: Counting objects:  76% (1550/2039)        
remote: Counting objects:  77% (1571/2039)        
remote: Counting objects:  78% (1591/2039)        
remote: Counting objects:  79% (1611/2039)        
remote: Counting objects:  80% (1632/2039)        
remote: Counting objects:  81% (1652/2039)        
remote: Counting objects:  82% (1672/2039)        
remote: Counting objects:  83% (1693/2039)        
remote: Counting objects:  84% (1713/2039)        
remote: Counting objects:  85% (1734/2039)        
remote: Counting objects:  86% (1754/2039)        
remote: Counting objects:  87% (1774/2039)        
remote: Counting objects:  88% (1795/2039)        
remote: Counting objects:  89% (1815/2039)        
remote: Counting objects:  90% (1836/2039)        
remote: Counting objects:  91% (1856/2039)        
remote: Counting objects:  92% (1876/2039)        
remote: Counting objects:  93% (1897/2039)        
remote: Counting objects:  94% (1917/2039)        
remote: Counting objects:  95% (1938/2039)        
remote: Counting objects:  96% (1958/2039)        
remote: Counting objects:  97% (1978/2039)        
remote: Counting objects:  98% (1999/2039)        
remote: Counting objects:  99% (2019/2039)        
remote: Counting objects: 100% (2039/2039)        
remote: Counting objects: 100% (2039/2039), done.        
remote: Compressing objects:   0% (1/1518)        
remote: Compressing objects:   1% (16/1518)        
remote: Compressing objects:   2% (31/1518)        
remote: Compressing objects:   3% (46/1518)        
remote: Compressing objects:   4% (61/1518)        
remote: Compressing objects:   5% (76/1518)        
remote: Compressing objects:   6% (92/1518)        
remote: Compressing objects:   7% (107/1518)        
remote: Compressing objects:   8% (122/1518)        
remote: Compressing objects:   9% (137/1518)        
remote: Compressing objects:  10% (152/1518)        
remote: Compressing objects:  11% (167/1518)        
remote: Compressing objects:  12% (183/1518)        
remote: Compressing objects:  13% (198/1518)        
remote: Compressing objects:  14% (213/1518)        
remote: Compressing objects:  15% (228/1518)        
remote: Compressing objects:  16% (243/1518)        
remote: Compressing objects:  17% (259/1518)        
remote: Compressing objects:  18% (274/1518)        
remote: Compressing objects:  19% (289/1518)        
remote: Compressing objects:  20% (304/1518)        
remote: Compressing objects:  21% (319/1518)        
remote: Compressing objects:  22% (334/1518)        
remote: Compressing objects:  23% (350/1518)        
remote: Compressing objects:  24% (365/1518)        
remote: Compressing objects:  25% (380/1518)        
remote: Compressing objects:  26% (395/1518)        
remote: Compressing objects:  27% (410/1518)        
remote: Compressing objects:  28% (426/1518)        
remote: Compressing objects:  29% (441/1518)        
remote: Compressing objects:  30% (456/1518)        
remote: Compressing objects:  31% (471/1518)        
remote: Compressing objects:  32% (486/1518)        
remote: Compressing objects:  33% (501/1518)        
remote: Compressing objects:  34% (517/1518)        
remote: Compressing objects:  35% (532/1518)        
remote: Compressing objects:  36% (547/1518)        
remote: Compressing objects:  37% (562/1518)        
remote: Compressing objects:  38% (577/1518)        
remote: Compressing objects:  39% (593/1518)        
remote: Compressing objects:  40% (608/1518)        
remote: Compressing objects:  41% (623/1518)        
remote: Compressing objects:  42% (638/1518)        
remote: Compressing objects:  43% (653/1518)        
remote: Compressing objects:  44% (668/1518)        
remote: Compressing objects:  45% (684/1518)        
remote: Compressing objects:  46% (699/1518)        
remote: Compressing objects:  47% (714/1518)        
remote: Compressing objects:  48% (729/1518)        
remote: Compressing objects:  49% (744/1518)        
remote: Compressing objects:  50% (759/1518)        
remote: Compressing objects:  51% (775/1518)        
remote: Compressing objects:  52% (790/1518)        
remote: Compressing objects:  53% (805/1518)        
remote: Compressing objects:  54% (820/1518)        
remote: Compressing objects:  55% (835/1518)        
remote: Compressing objects:  56% (851/1518)        
remote: Compressing objects:  57% (866/1518)        
remote: Compressing objects:  58% (881/1518)        
remote: Compressing objects:  59% (896/1518)        
remote: Compressing objects:  60% (911/1518)        
remote: Compressing objects:  61% (926/1518)        
remote: Compressing objects:  62% (942/1518)        
remote: Compressing objects:  63% (957/1518)        
remote: Compressing objects:  64% (972/1518)        
remote: Compressing objects:  65% (987/1518)        
remote: Compressing objects:  66% (1002/1518)        
remote: Compressing objects:  67% (1018/1518)        
remote: Compressing objects:  68% (1033/1518)        
remote: Compressing objects:  69% (1048/1518)        
remote: Compressing objects:  70% (1063/1518)        
remote: Compressing objects:  71% (1078/1518)        
remote: Compressing objects:  72% (1093/1518)        
remote: Compressing objects:  73% (1109/1518)        
remote: Compressing objects:  74% (1124/1518)        
remote: Compressing objects:  75% (1139/1518)        
remote: Compressing objects:  76% (1154/1518)        
remote: Compressing objects:  77% (1169/1518)        
remote: Compressing objects:  78% (1185/1518)        
remote: Compressing objects:  79% (1200/1518)        
remote: Compressing objects:  80% (1215/1518)        
remote: Compressing objects:  81% (1230/1518)        
remote: Compressing objects:  82% (1245/1518)        
remote: Compressing objects:  83% (1260/1518)        
remote: Compressing objects:  84% (1276/1518)        
remote: Compressing objects:  85% (1291/1518)        
remote: Compressing objects:  86% (1306/1518)        
remote: Compressing objects:  87% (1321/1518)        
remote: Compressing objects:  88% (1336/1518)        
remote: Compressing objects:  89% (1352/1518)        
remote: Compressing objects:  90% (1367/1518)        
remote: Compressing objects:  91% (1382/1518)        
remote: Compressing objects:  92% (1397/1518)        
remote: Compressing objects:  93% (1412/1518)        
remote: Compressing objects:  94% (1427/1518)        
remote: Compressing objects:  95% (1443/1518)        
remote: Compressing objects:  96% (1458/1518)        
remote: Compressing objects:  97% (1473/1518)        
remote: Compressing objects:  98% (1488/1518)        
remote: Compressing objects:  99% (1503/1518)        
remote: Compressing objects: 100% (1518/1518)        
remote: Compressing objects: 100% (1518/1518), done.        
Receiving objects:   0% (1/2039)
Receiving objects:   1% (21/2039)
Receiving objects:   2% (41/2039)
Receiving objects:   3% (62/2039)
Receiving objects:   4% (82/2039)
Receiving objects:   5% (102/2039)
Receiving objects:   6% (123/2039)
Receiving objects:   7% (143/2039)
Receiving objects:   8% (164/2039)
Receiving objects:   9% (184/2039)
Receiving objects:  10% (204/2039)
Receiving objects:  11% (225/2039)
Receiving objects:  12% (245/2039)
Receiving objects:  13% (266/2039)
Receiving objects:  14% (286/2039)
Receiving objects:  15% (306/2039)
Receiving objects:  16% (327/2039)
Receiving objects:  17% (347/2039)
Receiving objects:  18% (368/2039)
Receiving objects:  19% (388/2039)
Receiving objects:  20% (408/2039)
Receiving objects:  21% (429/2039)
Receiving objects:  22% (449/2039)
Receiving objects:  23% (469/2039)
Receiving objects:  24% (490/2039)
Receiving objects:  25% (510/2039)
Receiving objects:  26% (531/2039)
Receiving objects:  27% (551/2039)
Receiving objects:  28% (571/2039)
Receiving objects:  29% (592/2039)
Receiving objects:  30% (612/2039)
Receiving objects:  31% (633/2039)
Receiving objects:  31% (643/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  32% (653/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  33% (673/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  34% (694/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  35% (714/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  36% (735/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  37% (755/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  38% (775/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  39% (796/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  40% (816/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  41% (836/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  42% (857/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  43% (877/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  44% (898/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  45% (918/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  46% (938/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  47% (959/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  48% (979/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  49% (1000/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  50% (1020/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  51% (1040/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  52% (1061/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  53% (1081/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  54% (1102/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  55% (1122/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  56% (1142/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  57% (1163/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  58% (1183/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  59% (1204/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  60% (1224/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  61% (1244/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  62% (1265/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  63% (1285/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  64% (1305/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  65% (1326/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  66% (1346/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  67% (1367/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  68% (1387/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  69% (1407/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  70% (1428/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  71% (1448/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  72% (1469/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  73% (1489/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  74% (1509/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  75% (1530/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  76% (1550/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  77% (1571/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  78% (1591/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  79% (1611/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  80% (1632/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  81% (1652/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  82% (1672/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  83% (1693/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  84% (1713/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  85% (1734/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  86% (1754/2039), 19.92 MiB | 19.72 MiB/s
Receiving objects:  87% (1774/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  88% (1795/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  89% (1815/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  90% (1836/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  91% (1856/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  92% (1876/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  93% (1897/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  94% (1917/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  95% (1938/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  96% (1958/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  97% (1978/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  98% (1999/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects:  99% (2019/2039), 33.25 MiB | 22.00 MiB/s
remote: Total 2039 (delta 349), reused 1685 (delta 273), pack-reused 0 (from 0)        
Receiving objects: 100% (2039/2039), 33.25 MiB | 22.00 MiB/s
Receiving objects: 100% (2039/2039), 36.93 MiB | 22.40 MiB/s, done.
Resolving deltas:   0% (0/349)
Resolving deltas:   1% (4/349)
Resolving deltas:   2% (7/349)
Resolving deltas:   3% (11/349)
Resolving deltas:   4% (14/349)
Resolving deltas:   5% (18/349)
Resolving deltas:   6% (21/349)
Resolving deltas:   7% (25/349)
Resolving deltas:   8% (28/349)
Resolving deltas:   9% (32/349)
Resolving deltas:  10% (35/349)
Resolving deltas:  11% (39/349)
Resolving deltas:  12% (42/349)
Resolving deltas:  13% (46/349)
Resolving deltas:  14% (49/349)
Resolving deltas:  15% (53/349)
Resolving deltas:  16% (56/349)
Resolving deltas:  17% (60/349)
Resolving deltas:  18% (63/349)
Resolving deltas:  19% (67/349)
Resolving deltas:  20% (70/349)
Resolving deltas:  21% (74/349)
Resolving deltas:  22% (77/349)
Resolving deltas:  23% (81/349)
Resolving deltas:  24% (84/349)
Resolving deltas:  25% (88/349)
Resolving deltas:  26% (91/349)
Resolving deltas:  27% (95/349)
Resolving deltas:  28% (98/349)
Resolving deltas:  29% (102/349)
Resolving deltas:  30% (105/349)
Resolving deltas:  31% (109/349)
Resolving deltas:  32% (112/349)
Resolving deltas:  33% (116/349)
Resolving deltas:  34% (119/349)
Resolving deltas:  35% (123/349)
Resolving deltas:  36% (126/349)
Resolving deltas:  37% (130/349)
Resolving deltas:  38% (133/349)
Resolving deltas:  39% (137/349)
Resolving deltas:  40% (140/349)
Resolving deltas:  41% (144/349)
Resolving deltas:  42% (148/349)
Resolving deltas:  43% (151/349)
Resolving deltas:  44% (155/349)
Resolving deltas:  45% (158/349)
Resolving deltas:  46% (161/349)
Resolving deltas:  47% (165/349)
Resolving deltas:  48% (168/349)
Resolving deltas:  49% (172/349)
Resolving deltas:  50% (177/349)
Resolving deltas:  51% (178/349)
Resolving deltas:  52% (182/349)
Resolving deltas:  53% (185/349)
Resolving deltas:  54% (189/349)
Resolving deltas:  55% (192/349)
Resolving deltas:  56% (197/349)
Resolving deltas:  57% (199/349)
Resolving deltas:  58% (203/349)
Resolving deltas:  59% (206/349)
Resolving deltas:  60% (210/349)
Resolving deltas:  61% (213/349)
Resolving deltas:  62% (217/349)
Resolving deltas:  63% (220/349)
Resolving deltas:  64% (224/349)
Resolving deltas:  65% (227/349)
Resolving deltas:  66% (231/349)
Resolving deltas:  67% (234/349)
Resolving deltas:  68% (238/349)
Resolving deltas:  69% (241/349)
Resolving deltas:  70% (245/349)
Resolving deltas:  71% (248/349)
Resolving deltas:  73% (255/349)
Resolving deltas:  74% (259/349)
Resolving deltas:  75% (262/349)
Resolving deltas:  76% (266/349)
Resolving deltas:  77% (269/349)
Resolving deltas:  78% (273/349)
Resolving deltas:  79% (276/349)
Resolving deltas:  80% (280/349)
Resolving deltas:  81% (283/349)
Resolving deltas:  82% (287/349)
Resolving deltas:  83% (290/349)
Resolving deltas:  84% (294/349)
Resolving deltas:  85% (297/349)
Resolving deltas:  86% (302/349)
Resolving deltas:  87% (304/349)
Resolving deltas:  88% (308/349)
Resolving deltas:  89% (311/349)
Resolving deltas:  90% (315/349)
Resolving deltas:  91% (318/349)
Resolving deltas:  92% (322/349)
Resolving deltas:  93% (325/349)
Resolving deltas:  94% (329/349)
Resolving deltas:  95% (332/349)
Resolving deltas:  96% (337/349)
Resolving deltas:  97% (339/349)
Resolving deltas:  98% (343/349)
Resolving deltas:  99% (346/349)
Resolving deltas: 100% (349/349)
Resolving deltas: 100% (349/349), done.

== Checking out commit hash 270c6691ce0dd4a3577fb8ae3a86b16543279a2d ==
> /usr/bin/git reset --hard 270c6691ce0dd4a3577fb8ae3a86b16543279a2d
HEAD is now at 270c669 fix: resolve YAML syntax error in IPA verification script

Set up code signing identities
2s




== Initializing code signing for iOS ==

> keychain initialize
Initialize new keychain to store code signing certificates at /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db
Create keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db
Set keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db timeout to "no timeout"
Set keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db to system default keychain
Unlock keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db

Saved provisioning profile "TL247_mobpro_tradeline_01" to "/Users/builder/Library/MobileDevice/Provisioning Profiles/provisioning_profile_p1yz5_ll.mobileprovision"
Saved code signing certificate "TL247-Apple-Distribution-2025" to "/Users/builder/Library/MobileDevice/Certificates/code_signing_certificate_dzwxzr3f.p12"
> keychain add-certificates --certificate /Users/builder/Library/MobileDevice/Certificates/code_signing_certificate_dzwxzr3f.p12
Add certificates to keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db
Searching for files matching /Users/builder/Library/MobileDevice/Certificates/code_signing_certificate_dzwxzr3f.p12
Add certificate /Users/builder/Library/MobileDevice/Certificates/code_signing_certificate_dzwxzr3f.p12 to keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db
security: SecKeychainItemImport: Unable to decode the provided data.
1 key imported.
1 certificate imported.

Runtime versions (fail fast)
< 1s



Show command
v20.19.0
10.9.4
Xcode 16.4
Build version 16F6

Install dependencies
12s



Show command

added 938 packages in 12s

Quality gates
18s



Show command

> vite_react_shadcn_ts@1.0.7 lint
> eslint . --ext .ts,.tsx && node scripts/check-edge-imports.mjs

[check-edge-imports] No unsupported "npm:" imports detected in Supabase functions.

> vite_react_shadcn_ts@1.0.7 typecheck
> tsc -p tsconfig.json --noEmit


> vite_react_shadcn_ts@1.0.7 test:unit
> node scripts/run-vitest.mjs


 RUN  v2.1.9 /Users/builder/clone

 ✓ supabase/functions/_shared/__tests__/vision_anchor.test.ts (22 tests) 35ms
 ✓ supabase/functions/_shared/__tests__/compliance.test.ts (38 tests) 57ms
 ✓ src/lib/__tests__/errorReporter.test.ts (14 tests | 1 skipped) 258ms
stderr | src/hooks/__tests__/usePasswordSecurity.test.ts > usePasswordSecurity > checkPasswordBreach > should handle API errors gracefully
📊 Error Report: {
  type: 'error',
  message: 'Password breach check error: Service unavailable',
  timestamp: '2025-12-29T00:11:24.365Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { error: { message: 'Service unavailable' } }
}

stderr | src/hooks/__tests__/usePasswordSecurity.test.ts > usePasswordSecurity > checkPasswordBreach > should handle network errors
📊 Error Report: {
  type: 'error',
  message: 'Password security check failed: Network error',
  stack: 'Error: Network error\n' +
    '    at /Users/builder/clone/src/hooks/__tests__/usePasswordSecurity.test.ts:185:36\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:146:14\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:533:11\n' +
    '    at runWithTimeout (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:39:7)\n' +
    '    at runTest (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1056:17)\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)\n' +
    '    at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)\n' +
    '    at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)\n' +
    '    at runFiles (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1262:5)',
  timestamp: '2025-12-29T00:11:24.375Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    error: Error: Network error
        at /Users/builder/clone/src/hooks/__tests__/usePasswordSecurity.test.ts:185:36
        at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:146:14
        at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:533:11
        at runWithTimeout (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:39:7)
        at runTest (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1056:17)
        at processTicksAndRejections (node:internal/process/task_queues:95:5)
        at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)
        at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)
        at runSuite (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1205:15)
        at runFiles (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1262:5)
  }
}

 ✓ src/hooks/__tests__/usePasswordSecurity.test.ts (17 tests) 142ms
stderr | src/hooks/__tests__/useSecureFormSubmission.test.ts > useSecureFormSubmission > rate limiting > should preserve the server limit when a subsequent rate limit check errors
Warning: An update to TestComponent inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act
    at TestComponent (/Users/builder/clone/node_modules/@testing-library/react/dist/pure.js:328:5)

stderr | src/hooks/__tests__/useAuth.test.ts > useAuth > initial state > should start with loading state
Warning: An update to TestComponent inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act
    at TestComponent (/Users/builder/clone/node_modules/@testing-library/react/dist/pure.js:328:5)

stderr | src/hooks/__tests__/useAuth.test.ts > useAuth > initial state > should initialize with null user and session
Warning: An update to TestComponent inside a test was not wrapped in act(...).

When testing, code that causes React state updates should be wrapped into act(...):

act(() => {
  /* fire events that update state */
});
/* assert on the output */

This ensures that you're testing the behavior the user would see in the browser. Learn more at https://reactjs.org/link/wrap-tests-with-act
    at TestComponent (/Users/builder/clone/node_modules/@testing-library/react/dist/pure.js:328:5)

 ✓ src/hooks/__tests__/useSecureFormSubmission.test.ts (22 tests) 296ms
stderr | src/hooks/__tests__/useAuth.test.ts > useAuth > session handling > should handle malformed token errors
📊 Error Report: {
  type: 'error',
  message: '[Auth] Detected malformed token, clearing session: JWT token is malformed',
  timestamp: '2025-12-29T00:11:24.598Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development'
}

stderr | src/hooks/__tests__/useAuth.test.ts > useAuth > session handling > should handle invalid token errors
📊 Error Report: {
  type: 'error',
  message: '[Auth] Detected malformed token, clearing session: Invalid JWT token',
  timestamp: '2025-12-29T00:11:24.645Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development'
}

 ✓ src/hooks/__tests__/useAuth.test.ts (10 tests) 266ms
stdout | supabase/functions/_shared/__tests__/notify_owner.test.ts > notify_owner runtime service > returns no_owner_email_configured when email not set
No owner email configured (OWNER_NOTIFY_EMAIL)

stdout | supabase/functions/_shared/__tests__/notify_owner.test.ts > notify_owner runtime service > respects cooldown when recent notifications exist
Notification cooldown active for warranty_risk_detected

 ✓ supabase/functions/_shared/__tests__/notify_owner.test.ts (20 tests) 35ms
 ✓ src/lib/__tests__/reportError.fallback.test.ts (8 tests) 21ms
stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > makeBootDecision > should return SKIP_SPLASH when SPLASH_V2_ENABLED=false
[BootCoordinator] Boot decision made: { type: 'SKIP_SPLASH', reason: 'SPLASH_V2_ENABLED=false' }

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > makeBootDecision > should return SHOW_V2_FULL when force show is enabled
[BootCoordinator] Boot decision made: { type: 'SHOW_V2_FULL', reason: 'SPLASH_V2_FORCE_SHOW=true' }

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > makeBootDecision > should return SHOW_V2_FULL for new version
[BootCoordinator] Boot decision made: {
  type: 'SHOW_V2_FULL',
  reason: 'New version: dev-local (last seen: never)'
}

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > makeBootDecision > should return SHOW_V2_QUICK_FADE when version already seen
[BootCoordinator] Boot decision made: {
  type: 'SHOW_V2_QUICK_FADE',
  reason: 'Version already seen: dev-local'
}

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > makeBootDecision > should return cached decision on subsequent calls
[BootCoordinator] Boot decision made: {
  type: 'SHOW_V2_FULL',
  reason: 'New version: dev-local (last seen: never)'
}
[BootCoordinator] Returning cached decision: SHOW_V2_FULL

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > hasBootDecisionBeenMade > should return true after decision is made
[BootCoordinator] Boot decision made: {
  type: 'SHOW_V2_FULL',
  reason: 'New version: dev-local (last seen: never)'
}

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > getSplashDuration > should return correct duration for SHOW_V2_FULL
[BootCoordinator] Boot decision made: { type: 'SHOW_V2_FULL', reason: 'SPLASH_V2_FORCE_SHOW=true' }

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > getSplashDuration > should return quick fade duration for repeat visit
[BootCoordinator] Boot decision made: {
  type: 'SHOW_V2_QUICK_FADE',
  reason: 'Version already seen: dev-local'
}

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > onSplashV2Complete > should persist version after full splash
[BootCoordinator] Boot decision made: { type: 'SHOW_V2_FULL', reason: 'SPLASH_V2_FORCE_SHOW=true' }
[BootCoordinator] Splash v2 marked as seen for version: dev-local

stdout | src/lib/boot/__tests__/BootCoordinator.test.ts > BootCoordinator > Hard guard: No duplicate splash > should prevent both legacy and v2 from running by returning cached decision
[BootCoordinator] Boot decision made: { type: 'SHOW_V2_FULL', reason: 'SPLASH_V2_FORCE_SHOW=true' }
[BootCoordinator] Returning cached decision: SHOW_V2_FULL

 ✓ src/lib/boot/__tests__/BootCoordinator.test.ts (15 tests) 101ms
stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > existing membership > should handle membership check errors gracefully
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: membership check warning: Database error',
  timestamp: '2025-12-29T00:11:26.181Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > new membership creation > should handle function invocation errors
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: start-trial error: Function error',
  timestamp: '2025-12-29T00:11:26.196Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > new membership creation > should handle function response with ok: false
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: start-trial failed: Trial creation failed',
  timestamp: '2025-12-29T00:11:26.197Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > error handling > should handle unexpected errors gracefully
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: unexpected error: Unexpected error',
  stack: 'Error: Unexpected error\n' +
    '    at Object.<anonymous> (/Users/builder/clone/src/lib/__tests__/ensureMembership.test.ts:216:15)\n' +
    '    at Object.mockCall (file:///Users/builder/clone/node_modules/@vitest/spy/dist/index.js:61:17)\n' +
    '    at Object.from (file:///Users/builder/clone/node_modules/tinyspy/dist/index.js:45:80)\n' +
    '    at Module.ensureMembership (/Users/builder/clone/src/lib/ensureMembership.ts:18:8)\n' +
    '    at /Users/builder/clone/src/lib/__tests__/ensureMembership.test.ts:219:28\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:146:14\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:533:11\n' +
    '    at runWithTimeout (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:39:7)\n' +
    '    at runTest (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1056:17)\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)',
  timestamp: '2025-12-29T00:11:26.209Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > error handling > should provide error message for unexpected errors
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: unexpected error: Network timeout',
  stack: 'Error: Network timeout\n' +
    '    at Object.<anonymous> (/Users/builder/clone/src/lib/__tests__/ensureMembership.test.ts:227:15)\n' +
    '    at Object.mockCall (file:///Users/builder/clone/node_modules/@vitest/spy/dist/index.js:61:17)\n' +
    '    at Object.from (file:///Users/builder/clone/node_modules/tinyspy/dist/index.js:45:80)\n' +
    '    at Module.ensureMembership (/Users/builder/clone/src/lib/ensureMembership.ts:18:8)\n' +
    '    at /Users/builder/clone/src/lib/__tests__/ensureMembership.test.ts:230:28\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:146:14\n' +
    '    at file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:533:11\n' +
    '    at runWithTimeout (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:39:7)\n' +
    '    at runTest (file:///Users/builder/clone/node_modules/@vitest/runner/dist/index.js:1056:17)\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)',
  timestamp: '2025-12-29T00:11:26.212Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

stderr | src/lib/__tests__/ensureMembership.test.ts > ensureMembership > error handling > should handle errors without message
📊 Error Report: {
  type: 'error',
  message: 'ensureMembership: unexpected error: undefined',
  stack: undefined,
  timestamp: '2025-12-29T00:11:26.214Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: { userId: 'user-123' }
}

 ✓ src/lib/__tests__/ensureMembership.test.ts (11 tests) 43ms
 ✓ src/stores/__tests__/userPreferencesStore.test.ts (16 tests) 20ms
 ✓ src/components/errors/__tests__/ErrorBoundary.test.tsx (11 tests) 312ms
 ✓ src/lib/__tests__/errorReporter.enhanced.test.ts (20 tests) 26ms
stderr | src/lib/boot/__tests__/splashPersistence.test.ts > splashPersistence > localStorage unavailable > should handle localStorage errors gracefully
[SplashPersistence] Unable to persist version
[SplashPersistence] Unable to persist version

 ✓ src/lib/boot/__tests__/splashPersistence.test.ts (17 tests) 19ms
 ✓ src/stores/__tests__/dashboardStore.test.ts (17 tests) 16ms
 ✓ src/pages/__tests__/AuthLanding.test.tsx (16 tests) 2825ms
   ✓ AuthLanding - P0 Fix: Form Validation and Handler > Form rendering > should render form with all fields 379ms
   ✓ AuthLanding - P0 Fix: Form Validation and Handler > Form validation > should show validation error for short business name 324ms
   ✓ AuthLanding - P0 Fix: Form Validation and Handler > Form validation > should show validation error for invalid email 485ms
   ✓ AuthLanding - P0 Fix: Form Validation and Handler > Form validation > should trim whitespace from inputs 339ms
 ✓ supabase/functions/_shared/__tests__/twilio-signature.test.ts (6 tests) 19ms
 ✓ src/utils/__tests__/errorObservability.test.ts (7 tests) 21ms
 ✓ supabase/functions/_shared/__tests__/http-security.test.ts (4 tests) 60ms
 ✓ src/components/errors/__tests__/SafeErrorBoundary.test.tsx (7 tests) 201ms
 ✓ src/utils/__tests__/utils.test.ts (8 tests) 19ms
 ✓ src/integrations/supabase/client.test.ts (5 tests) 374ms
   ✓ Supabase Client > should export isSupabaseEnabled flag 371ms
 ✓ src/integrations/omnlink/__tests__/omnlink.test.ts (3 tests) 7ms
stdout | src/pages/__tests__/routes.smoke.test.tsx > Router Smoke Tests > should render Index page with hero section
[DEBUG H1] Overlay 0 scroll blocking check {
  className: 'landing-wallpaper',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 1 scroll blocking check {
  className: 'landing-mask',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 2 scroll blocking check {
  className: 'hero-gradient-overlay',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 3 scroll blocking check {
  className: 'content-gradient-overlay',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H2] Page dimensions check {
  documentHeight: 0,
  documentClientHeight: 0,
  bodyHeight: 0,
  bodyClientHeight: 0,
  windowInnerHeight: 768,
  scrollY: 0
}
[DEBUG H3] Footer position check {
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  height: 0,
  isInViewport: true,
  scrollHeight: 0,
  clientHeight: 0
}
[DEBUG H4] Z-index stacking check {
  mainContentZIndex: '',
  overlayZIndex: '',
  mainContentPosition: '',
  overlayPosition: '',
  overlayPointerEvents: 'auto'
}
[DEBUG H5] Main container overflow check {
  overflow: '',
  overflowY: '',
  height: '',
  minHeight: '',
  maxHeight: '',
  scrollHeight: 0,
  clientHeight: 0,
  rectHeight: 0,
  canScroll: false
}

 ✓ src/pages/__tests__/routes.smoke.test.tsx (4 tests) 813ms
stderr | ErrorReporter.report (/Users/builder/clone/src/lib/errorReporter.ts:172:15)
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.704Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.708Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.710Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.711Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.712Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.713Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.714Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:29.714Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}

 ✓ src/components/layout/__tests__/Header.spec.tsx (1 test) 522ms
   ✓ Header > exposes a mobile burger menu with accessibility hooks 521ms
 ✓ src/components/ui/ChatIcon.test.tsx (6 tests) 105ms
 ✓ src/__tests__/voiceService.test.ts (1 test) 8ms
 ✓ src/components/dashboard/__tests__/NewDashboard.test.tsx (1 test) 210ms
stdout | src/pages/__tests__/Index.spec.tsx > Index page > renders without camelCase fetchPriority attributes on images
[DEBUG H1] Overlay 0 scroll blocking check {
  className: 'landing-wallpaper',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 1 scroll blocking check {
  className: 'landing-mask',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 2 scroll blocking check {
  className: 'hero-gradient-overlay',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H1] Overlay 3 scroll blocking check {
  className: 'content-gradient-overlay',
  position: '',
  pointerEvents: 'auto',
  zIndex: '',
  top: '',
  bottom: ''
}
[DEBUG H2] Page dimensions check {
  documentHeight: 0,
  documentClientHeight: 0,
  bodyHeight: 0,
  bodyClientHeight: 0,
  windowInnerHeight: 768,
  scrollY: 0
}
[DEBUG H3] Footer position check {
  top: 0,
  bottom: 0,
  left: 0,
  right: 0,
  height: 0,
  isInViewport: true,
  scrollHeight: 0,
  clientHeight: 0
}
[DEBUG H4] Z-index stacking check {
  mainContentZIndex: '',
  overlayZIndex: '',
  mainContentPosition: '',
  overlayPosition: '',
  overlayPointerEvents: 'auto'
}
[DEBUG H5] Main container overflow check {
  overflow: '',
  overflowY: '',
  height: '',
  minHeight: '',
  maxHeight: '',
  scrollHeight: 0,
  clientHeight: 0,
  rectHeight: 0,
  canScroll: false
}

 ✓ src/pages/__tests__/Index.spec.tsx (1 test) 618ms
   ✓ Index page > renders without camelCase fetchPriority attributes on images 617ms
stderr | ErrorReporter.report (/Users/builder/clone/src/lib/errorReporter.ts:172:15)
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.491Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.493Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.495Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.495Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.497Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.498Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.499Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: fetch failed',
  stack: 'TypeError: fetch failed\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at processTicksAndRejections (node:internal/process/task_queues:95:5)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:32.500Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: 'http://127.0.0.1:7244/ingest/1a394b6c-8b02-4da6-944b-d1731ecd3598',
    error: 'TypeError: fetch failed',
    wasNormalized: false
  }
}

 ✓ src/components/layout/__tests__/Header.test.tsx (1 test) 857ms
   ✓ Header user menu > moves the greeting into the avatar menu and closes on Escape 855ms
 ✓ src/utils/__tests__/runtime.test.ts (6 tests) 7ms
 ✓ src/lib/__tests__/safeMode.test.ts (2 tests) 17ms
 ✓ src/utils/__tests__/env.test.ts (4 tests) 5ms
 ✓ src/pages/__tests__/Contact.spec.tsx (1 test) 228ms
 ✓ src/__tests__/navigation.test.tsx (8 tests) 1174ms
   ✓ Navigation Pages > renders FAQ page without router collisions 691ms
 ✓ src/__tests__/sentimentService.test.ts (3 tests) 5ms
stderr | src/__tests__/routes/paths.test.ts
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: Failed to parse URL from /locales/en/common.json',
  stack: 'TypeError: Failed to parse URL from /locales/en/common.json\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:34.436Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: '/locales/en/common.json',
    error: 'TypeError: Failed to parse URL from /locales/en/common.json',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: Failed to parse URL from /locales/en/dashboard.json',
  stack: 'TypeError: Failed to parse URL from /locales/en/dashboard.json\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:34.439Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: '/locales/en/dashboard.json',
    error: 'TypeError: Failed to parse URL from /locales/en/dashboard.json',
    wasNormalized: false
  }
}

 ✓ src/pages/__tests__/Privacy.test.tsx (1 test) 387ms
   ✓ Privacy page call recording section > renders call recording disclosure with anchor 386ms
 ✓ src/components/layout/__tests__/Footer.test.tsx (1 test) 465ms
   ✓ Footer > renders brand, nav links, and trust badges 464ms
stderr | src/__tests__/routes/paths.test.ts
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: Failed to parse URL from /locales/en/common.json',
  stack: 'TypeError: Failed to parse URL from /locales/en/common.json\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at runNextTicks (node:internal/process/task_queues:60:5)\n' +
    '    at listOnTimeout (node:internal/timers:545:9)\n' +
    '    at processTimers (node:internal/timers:519:7)\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:34.793Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: '/locales/en/common.json',
    error: 'TypeError: Failed to parse URL from /locales/en/common.json',
    wasNormalized: false
  }
}
📊 Error Report: {
  type: 'network',
  message: 'Fetch failed: Failed to parse URL from /locales/en/dashboard.json',
  stack: 'TypeError: Failed to parse URL from /locales/en/dashboard.json\n' +
    '    at node:internal/deps/undici/undici:13502:13\n' +
    '    at window.fetch (/Users/builder/clone/src/lib/errorReporter.ts:106:26)',
  timestamp: '2025-12-29T00:11:34.794Z',
  url: 'http://localhost:3000/',
  userAgent: 'Mozilla/5.0 (darwin) AppleWebKit/537.36 (KHTML, like Gecko) jsdom/27.3.0',
  environment: 'development',
  metadata: {
    fetchUrl: '/locales/en/dashboard.json',
    error: 'TypeError: Failed to parse URL from /locales/en/dashboard.json',
    wasNormalized: false
  }
}

 ✓ src/__tests__/routes/paths.test.ts (1 test) 2ms

 Test Files  39 passed (39)
      Tests  355 passed | 1 skipped (356)
   Start at  00:11:21
   Duration  13.40s (transform 2.63s, setup 6.81s, collect 13.43s, tests 10.59s, environment 37.74s, prepare 5.25s)

Playwright smoke
2m 42s



Show command
Downloading Chromium 143.0.7499.4 (playwright build v1200) from https://cdn.playwright.dev/dbazure/download/playwright/builds/chromium/1200/chromium-mac-arm64.zip
|                                                                                |   0% of 159.6 MiB
|■■■■■■■■                                                                        |  10% of 159.6 MiB
|■■■■■■■■■■■■■■■■                                                                |  20% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■                                                        |  30% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                                |  40% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                        |  50% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                |  60% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                        |  70% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                |  80% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■        |  90% of 159.6 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■| 100% of 159.6 MiB
Chromium 143.0.7499.4 (playwright build v1200) downloaded to /Users/builder/Library/Caches/ms-playwright/chromium-1200
Downloading FFMPEG playwright build v1011 from https://cdn.playwright.dev/dbazure/download/playwright/builds/ffmpeg/1011/ffmpeg-mac-arm64.zip
|                                                                                |   1% of 1 MiB
|■■■■■■■■                                                                        |  10% of 1 MiB
|■■■■■■■■■■■■■■■■                                                                |  21% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■                                                        |  30% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                                |  40% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                        |  51% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                |  60% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                        |  71% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                |  80% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■        |  90% of 1 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■| 100% of 1 MiB
FFMPEG playwright build v1011 downloaded to /Users/builder/Library/Caches/ms-playwright/ffmpeg-1011
Downloading Chromium Headless Shell 143.0.7499.4 (playwright build v1200) from https://cdn.playwright.dev/dbazure/download/playwright/builds/chromium/1200/chromium-headless-shell-mac-arm64.zip
|                                                                                |   0% of 89.7 MiB
|■■■■■■■■                                                                        |  10% of 89.7 MiB
|■■■■■■■■■■■■■■■■                                                                |  20% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■                                                        |  30% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                                |  40% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                        |  50% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                                |  60% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                        |  70% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■                |  80% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■        |  90% of 89.7 MiB
|■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■| 100% of 89.7 MiB
Chromium Headless Shell 143.0.7499.4 (playwright build v1200) downloaded to /Users/builder/Library/Caches/ms-playwright/chromium_headless_shell-1200

> vite_react_shadcn_ts@1.0.7 test:e2e:smoke
> playwright test tests/smoke.spec.ts tests/blank-screen.spec.ts tests/cta-smoke.spec.ts tests/preview-health.spec.ts

[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 preview:test
[WebServer] > cross-env VITE_ENABLE_TEST_ERROR=true NEXT_PUBLIC_ENABLE_TEST_ERROR=true npm run build && cross-env VITE_ENABLE_TEST_ERROR=true NEXT_PUBLIC_ENABLE_TEST_ERROR=true vite preview --port 4176 --strictPort
[WebServer] 
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 prebuild
[WebServer] > node scripts/check-required-files.mjs
[WebServer] 
[WebServer] ✅ All required files found
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 build
[WebServer] > vite build
[WebServer] 
[WebServer] vite v7.3.0 building client environment for production...
[WebServer] transforming...
[WebServer] node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (46:10): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
[WebServer] node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (94:21): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
[WebServer] ✓ 2387 modules transformed.
[WebServer] rendering chunks...
[WebServer] [plugin vite:reporter] 
[WebServer] (!) /Users/builder/clone/src/lib/errorReporter.ts is dynamically imported by /Users/builder/clone/src/hooks/useAuth.ts but also statically imported by /Users/builder/clone/src/components/dashboard/QuickActionsCard.tsx, /Users/builder/clone/src/components/dashboard/new/WinsSection.tsx, /Users/builder/clone/src/components/errors/SafeErrorBoundary.tsx, /Users/builder/clone/src/components/sections/LeadCaptureCard.tsx, /Users/builder/clone/src/components/sections/LeadCaptureForm.tsx, /Users/builder/clone/src/components/ui/MiniChat.tsx, /Users/builder/clone/src/hooks/useAnalytics.ts, /Users/builder/clone/src/hooks/useAuth.ts, /Users/builder/clone/src/hooks/useEnhancedDashboard.ts, /Users/builder/clone/src/hooks/usePasswordSecurity.ts, /Users/builder/clone/src/hooks/useSafeNavigation.ts, /Users/builder/clone/src/hooks/useSecureABTest.ts, /Users/builder/clone/src/hooks/useSecureAnalytics.ts, /Users/builder/clone/src/hooks/useSecureFormSubmission.ts, /Users/builder/clone/src/hooks/useTwilioCallData.ts, /Users/builder/clone/src/lib/ensureMembership.ts, /Users/builder/clone/src/lib/pwaInstall.ts, /Users/builder/clone/src/lib/swCleanup.ts, /Users/builder/clone/src/pages/Auth.tsx, /Users/builder/clone/src/pages/Contact.tsx, /Users/builder/clone/src/pages/Index.tsx, /Users/builder/clone/src/utils/safetyHelpers.ts, dynamic import will not move module into another chunk.
[WebServer] 
[WebServer] computing gzip size...
[WebServer] dist/assets/apex-wordmark-DoKihJda.png               17.66 kB
[WebServer] dist/index.html                                      21.22 kB │ gzip:   6.43 kB
[WebServer] dist/assets/alberta-innovates-BjA-ej2W.png           41.57 kB
[WebServer] dist/assets/official-logo-CJuizMTY.png               50.37 kB
[WebServer] dist/assets/erin-IH91Xwvd.png                       304.67 kB
[WebServer] dist/assets/built-canadian-AypIzTtN.svg             758.45 kB │ gzip: 570.78 kB
[WebServer] dist/assets/BACKGROUND_IMAGE1-BmVn5_cx.svg        1,065.27 kB │ gzip: 300.30 kB
[WebServer] dist/assets/roi-table-gLrgCKri.css                    0.85 kB │ gzip:   0.40 kB
[WebServer] dist/assets/index-BuaQgkEF.css                        3.11 kB │ gzip:   1.08 kB
[WebServer] dist/assets/index-DYv08kny.css                      151.37 kB │ gzip:  25.25 kB
[WebServer] dist/assets/arrow-left-BMvuhvmw.js                    0.16 kB │ gzip:   0.16 kB
[WebServer] dist/assets/circle-check-CLDsQdI1.js                  0.18 kB │ gzip:   0.16 kB
[WebServer] dist/assets/circle-x-B01wwqZq.js                      0.20 kB │ gzip:   0.17 kB
[WebServer] dist/assets/message-square-DDwWHgI3.js                0.23 kB │ gzip:   0.19 kB
[WebServer] dist/assets/message-circle-CYUG2rqo.js                0.23 kB │ gzip:   0.21 kB
[WebServer] dist/assets/database-AMbLVk4G.js                      0.24 kB │ gzip:   0.20 kB
[WebServer] dist/assets/external-link-Dclv9-7-.js                 0.24 kB │ gzip:   0.19 kB
[WebServer] dist/assets/circle-alert-BSFzF2Gy.js                  0.25 kB │ gzip:   0.18 kB
[WebServer] dist/assets/map-pin-B9Z0F_U3.js                       0.25 kB │ gzip:   0.22 kB
[WebServer] dist/assets/calendar-BwnRonA4.js                      0.25 kB │ gzip:   0.20 kB
[WebServer] dist/assets/key-DEr5xfG9.js                           0.26 kB │ gzip:   0.21 kB
[WebServer] dist/assets/send-DwwbEHDM.js                          0.28 kB │ gzip:   0.22 kB
[WebServer] dist/assets/users-2Uq-A3DO.js                         0.30 kB │ gzip:   0.22 kB
[WebServer] dist/assets/refresh-cw-MYAGC8Dd.js                    0.31 kB │ gzip:   0.22 kB
[WebServer] dist/assets/brandGradients-KgJGh5c5.js                0.44 kB │ gzip:   0.25 kB
[WebServer] dist/assets/performanceOptimizations-DPwb1cGZ.js      0.53 kB │ gzip:   0.29 kB
[WebServer] dist/assets/errorObservability-DaB9InDk.js            0.58 kB │ gzip:   0.35 kB
[WebServer] dist/assets/react-query-DdKjlrul.js                   0.76 kB │ gzip:   0.49 kB
[WebServer] dist/assets/LoginPage-CtVDxa26.js                     0.80 kB │ gzip:   0.47 kB
[WebServer] dist/assets/roiTableFix-Cr-xS_7t.js                   0.89 kB │ gzip:   0.42 kB
[WebServer] dist/assets/web-BsZYM3TQ.js                           1.00 kB │ gzip:   0.47 kB
[WebServer] dist/assets/heroGuardian-22GY0CLt.js                  1.43 kB │ gzip:   0.70 kB
[WebServer] dist/assets/PWAInstallBanner-CJG1gN0F.js              1.67 kB │ gzip:   0.82 kB
[WebServer] dist/assets/SEOHead-Cea8iGlm.js                       1.74 kB │ gzip:   0.71 kB
[WebServer] dist/assets/pwaInstall-BPLBtFw0.js                    1.96 kB │ gzip:   0.91 kB
[WebServer] dist/assets/index-Ce24umrQ.js                         2.30 kB │ gzip:   1.03 kB
[WebServer] dist/assets/select-D09djXw9.js                        3.07 kB │ gzip:   1.14 kB
[WebServer] dist/assets/AuthLanding-D39neuqJ.js                   3.16 kB │ gzip:   1.41 kB
[WebServer] dist/assets/tabs-DS1WhVbf.js                          3.35 kB │ gzip:   1.43 kB
[WebServer] dist/assets/PhoneApps-45xZRB-1.js                     3.46 kB │ gzip:   1.45 kB
[WebServer] dist/assets/index-BhWnW-Q1.js                         3.50 kB │ gzip:   1.59 kB
[WebServer] dist/assets/NotFound-B8PwB0to.js                      3.81 kB │ gzip:   1.48 kB
[WebServer] dist/assets/lovableGitHubMonitor-DNEumbYB.js          4.10 kB │ gzip:   1.59 kB
[WebServer] dist/assets/TeamInvite-aegPloy7.js                    4.11 kB │ gzip:   1.71 kB
[WebServer] dist/assets/Compare-CWrrS8iQ.js                       5.33 kB │ gzip:   1.67 kB
[WebServer] dist/assets/Integrations-CQn8E_KE.js                  5.44 kB │ gzip:   2.00 kB
[WebServer] dist/assets/ForwardingWizard-BhaGlYVl.js              5.51 kB │ gzip:   2.15 kB
[WebServer] dist/assets/CRMIntegration-DWch-uoT.js                6.13 kB │ gzip:   2.15 kB
[WebServer] dist/assets/Privacy-BMr58cMu.js                       6.16 kB │ gzip:   1.91 kB
[WebServer] dist/assets/radix-primitives-C-4XT4U0.js              6.24 kB │ gzip:   2.01 kB
[WebServer] dist/assets/ConnectionIndicator-hSvQ_AVR.js           6.68 kB │ gzip:   2.55 kB
[WebServer] dist/assets/Features-M8xbVpUR.js                      6.73 kB │ gzip:   2.82 kB
[WebServer] dist/assets/CampaignManager-C5U7DAs6.js               7.31 kB │ gzip:   2.43 kB
[WebServer] dist/assets/MessagingHealth-BIr71U0c.js               7.35 kB │ gzip:   2.18 kB
[WebServer] dist/assets/EmailIntegration-wKACy51Z.js              7.45 kB │ gzip:   2.44 kB
[WebServer] dist/assets/PreviewHealth-AWj5bqFO.js                 7.51 kB │ gzip:   2.95 kB
[WebServer] dist/assets/PhoneIntegration-0PFanaeL.js              7.54 kB │ gzip:   2.27 kB
[WebServer] dist/assets/lovableSaveFailsafe-B9546M9k.js           7.68 kB │ gzip:   2.48 kB
[WebServer] dist/assets/Pricing-BYA1m39J.js                       8.11 kB │ gzip:   2.87 kB
[WebServer] dist/assets/MessagingIntegration-Ciw7YuGG.js          8.26 kB │ gzip:   2.76 kB
[WebServer] dist/assets/TwilioEvidence-CYyEAK_p.js                9.45 kB │ gzip:   2.59 kB
[WebServer] dist/assets/browser-ponyfill-Bir_r7zy.js              9.99 kB │ gzip:   3.44 kB
[WebServer] dist/assets/FAQ-Ce3STpb5.js                          10.10 kB │ gzip:   3.84 kB
[WebServer] dist/assets/MiniChat-OOgJ96qZ.js                     10.31 kB │ gzip:   3.89 kB
[WebServer] dist/assets/MobileIntegration-C8prC3yD.js            10.48 kB │ gzip:   2.75 kB
[WebServer] dist/assets/Auth-ocdMaCmW.js                         10.48 kB │ gzip:   3.34 kB
[WebServer] dist/assets/AutomationIntegration-5T9qb0Oq.js        10.56 kB │ gzip:   3.35 kB
[WebServer] dist/assets/ClientDashboard-FmhD5liA.js              11.38 kB │ gzip:   3.46 kB
[WebServer] dist/assets/Contact-BMHbhmOe.js                      11.52 kB │ gzip:   3.88 kB
[WebServer] dist/assets/CallCenter-D9vY-DIa.js                   11.53 kB │ gzip:   4.13 kB
[WebServer] dist/assets/VoiceSettings-C60pvWHC.js                14.30 kB │ gzip:   4.35 kB
[WebServer] dist/assets/VoiceHealth-BEOrRiKQ.js                  14.49 kB │ gzip:   3.02 kB
[WebServer] dist/assets/Security-Bk1AUjwF.js                     14.67 kB │ gzip:   4.41 kB
[WebServer] dist/assets/ClientNumberOnboarding-CAxylIme.js       18.89 kB │ gzip:   5.35 kB
[WebServer] dist/assets/CallLogs-CZbFgyRq.js                     22.61 kB │ gzip:   7.26 kB
[WebServer] dist/assets/radix-forms-uNGDj7-j.js                  32.09 kB │ gzip:  10.58 kB
[WebServer] dist/assets/react-router-OXQyrdz8.js                 34.20 kB │ gzip:  12.46 kB
[WebServer] dist/assets/NewDashboard-BmSQdoC8.js                 36.44 kB │ gzip:   9.98 kB
[WebServer] dist/assets/radix-overlays-C7AmMIQn.js               91.96 kB │ gzip:  29.03 kB
[WebServer] dist/assets/react-vendor-CCDPu1A0.js                139.88 kB │ gzip:  45.14 kB
[WebServer] dist/assets/supabase-CzaIJPsd.js                    186.83 kB │ gzip:  47.03 kB
[WebServer] dist/assets/index-Cr4FCgdg.js                       340.24 kB │ gzip:  97.45 kB
[WebServer] ✓ built in 9.29s
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 postbuild
[WebServer] > npm run verify:app && npm run verify:icons && npm run verify:console
[WebServer] 
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 verify:app
[WebServer] > node scripts/verify-app.cjs
[WebServer] 
[WebServer] Node.js v20.19.0
[WebServer] [verify] Probing http://127.0.0.1:4176/
[WebServer]   ➜  Local:   http://127.0.0.1:4176/
[WebServer] VERIFY: PASS
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 verify:icons
[WebServer] > node scripts/verify_icons.mjs
[WebServer] 
[WebServer] Restored iOS 1024 icon -> ios/App/App/Assets.xcassets/AppIcon.appiconset/icon-1024.png
[WebServer] ✅ Icon set verified.
[WebServer] 
[WebServer] > vite_react_shadcn_ts@1.0.7 verify:console
[WebServer] > node scripts/verify-console-usage.mjs
[WebServer] 
[WebServer] 🔍 Verifying console usage in critical files...
[WebServer] 
[WebServer] 📄 Checking src/main.tsx...
[WebServer] ✅ src/main.tsx passed validation
[WebServer] 
[WebServer] ✅ All console usage checks passed!
[WebServer]   ➜  Local:   http://localhost:4176/
[WebServer]   ➜  Network: http://192.168.64.4:4176/

Running 150 tests using 1 worker
·······°°·····················°··························°°·····················
°··························°°·····················°···················
  9 skipped
  141 passed (2.5m)
::notice title=🎭 Playwright Run Summary::  9 skipped%0A  141 passed (2.5m)

Build web assets
8s



Show command

> vite_react_shadcn_ts@1.0.7 prebuild
> node scripts/check-required-files.mjs

✅ All required files found

> vite_react_shadcn_ts@1.0.7 build
> vite build

vite v7.3.0 building client environment for production...
transforming...
node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (46:10): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (94:21): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
✓ 2387 modules transformed.
rendering chunks...
[plugin vite:reporter] 
(!) /Users/builder/clone/src/lib/errorReporter.ts is dynamically imported by /Users/builder/clone/src/hooks/useAuth.ts but also statically imported by /Users/builder/clone/src/components/dashboard/QuickActionsCard.tsx, /Users/builder/clone/src/components/dashboard/new/WinsSection.tsx, /Users/builder/clone/src/components/errors/SafeErrorBoundary.tsx, /Users/builder/clone/src/components/sections/LeadCaptureCard.tsx, /Users/builder/clone/src/components/sections/LeadCaptureForm.tsx, /Users/builder/clone/src/components/ui/MiniChat.tsx, /Users/builder/clone/src/hooks/useAnalytics.ts, /Users/builder/clone/src/hooks/useAuth.ts, /Users/builder/clone/src/hooks/useEnhancedDashboard.ts, /Users/builder/clone/src/hooks/usePasswordSecurity.ts, /Users/builder/clone/src/hooks/useSafeNavigation.ts, /Users/builder/clone/src/hooks/useSecureABTest.ts, /Users/builder/clone/src/hooks/useSecureAnalytics.ts, /Users/builder/clone/src/hooks/useSecureFormSubmission.ts, /Users/builder/clone/src/hooks/useTwilioCallData.ts, /Users/builder/clone/src/lib/ensureMembership.ts, /Users/builder/clone/src/lib/pwaInstall.ts, /Users/builder/clone/src/lib/swCleanup.ts, /Users/builder/clone/src/pages/Auth.tsx, /Users/builder/clone/src/pages/Contact.tsx, /Users/builder/clone/src/pages/Index.tsx, /Users/builder/clone/src/utils/safetyHelpers.ts, dynamic import will not move module into another chunk.

computing gzip size...
dist/assets/apex-wordmark-DoKihJda.png               17.66 kB
dist/index.html                                      21.22 kB │ gzip:   6.43 kB
dist/assets/alberta-innovates-BjA-ej2W.png           41.57 kB
dist/assets/official-logo-CJuizMTY.png               50.37 kB
dist/assets/erin-IH91Xwvd.png                       304.67 kB
dist/assets/built-canadian-AypIzTtN.svg             758.45 kB │ gzip: 570.78 kB
dist/assets/BACKGROUND_IMAGE1-BmVn5_cx.svg        1,065.27 kB │ gzip: 300.30 kB
dist/assets/roi-table-gLrgCKri.css                    0.85 kB │ gzip:   0.40 kB
dist/assets/index-BuaQgkEF.css                        3.11 kB │ gzip:   1.08 kB
dist/assets/index-DYv08kny.css                      151.37 kB │ gzip:  25.25 kB
dist/assets/arrow-left-l0AoTFi5.js                    0.16 kB │ gzip:   0.16 kB
dist/assets/circle-check-CBevw9yK.js                  0.18 kB │ gzip:   0.16 kB
dist/assets/circle-x-X6ITLRE8.js                      0.20 kB │ gzip:   0.17 kB
dist/assets/message-square-BlJli4rx.js                0.23 kB │ gzip:   0.19 kB
dist/assets/message-circle-Chuq2fS3.js                0.23 kB │ gzip:   0.20 kB
dist/assets/database-DGhCcaZ7.js                      0.24 kB │ gzip:   0.19 kB
dist/assets/external-link--Uh018tL.js                 0.24 kB │ gzip:   0.19 kB
dist/assets/circle-alert-B_rJ3fpN.js                  0.25 kB │ gzip:   0.18 kB
dist/assets/map-pin-CNX8frrY.js                       0.25 kB │ gzip:   0.22 kB
dist/assets/calendar-D-CwI73W.js                      0.25 kB │ gzip:   0.20 kB
dist/assets/key-BFWFxK4T.js                           0.26 kB │ gzip:   0.21 kB
dist/assets/send-Cx3ryKnc.js                          0.28 kB │ gzip:   0.22 kB
dist/assets/users-CmRlGVsq.js                         0.30 kB │ gzip:   0.22 kB
dist/assets/refresh-cw-KQ2EnFhL.js                    0.31 kB │ gzip:   0.22 kB
dist/assets/brandGradients-KgJGh5c5.js                0.44 kB │ gzip:   0.25 kB
dist/assets/performanceOptimizations-DPwb1cGZ.js      0.53 kB │ gzip:   0.29 kB
dist/assets/errorObservability-DaB9InDk.js            0.58 kB │ gzip:   0.35 kB
dist/assets/react-query-DdKjlrul.js                   0.76 kB │ gzip:   0.49 kB
dist/assets/LoginPage-B6UwNWGI.js                     0.80 kB │ gzip:   0.47 kB
dist/assets/roiTableFix-Cr-xS_7t.js                   0.89 kB │ gzip:   0.42 kB
dist/assets/web-gvg0Juk9.js                           1.00 kB │ gzip:   0.47 kB
dist/assets/heroGuardian-22GY0CLt.js                  1.43 kB │ gzip:   0.70 kB
dist/assets/PWAInstallBanner-BJflqhXE.js              1.67 kB │ gzip:   0.82 kB
dist/assets/SEOHead-CFHI398J.js                       1.74 kB │ gzip:   0.71 kB
dist/assets/pwaInstall-6I8o5I8e.js                    1.96 kB │ gzip:   0.91 kB
dist/assets/index-Ce24umrQ.js                         2.30 kB │ gzip:   1.03 kB
dist/assets/select-Cl8Z79z-.js                        3.07 kB │ gzip:   1.14 kB
dist/assets/AuthLanding-CbCFg7QN.js                   3.16 kB │ gzip:   1.42 kB
dist/assets/tabs-B1ZOdcDR.js                          3.35 kB │ gzip:   1.43 kB
dist/assets/PhoneApps-dRK20II_.js                     3.46 kB │ gzip:   1.45 kB
dist/assets/index-Cl17-L-9.js                         3.50 kB │ gzip:   1.59 kB
dist/assets/NotFound-CDO9_uaF.js                      3.81 kB │ gzip:   1.48 kB
dist/assets/lovableGitHubMonitor-DNEumbYB.js          4.10 kB │ gzip:   1.59 kB
dist/assets/TeamInvite-BNL1M3K8.js                    4.11 kB │ gzip:   1.71 kB
dist/assets/Compare-CRBGXjaN.js                       5.33 kB │ gzip:   1.67 kB
dist/assets/Integrations-DeoBdyOz.js                  5.44 kB │ gzip:   2.00 kB
dist/assets/ForwardingWizard-n-SgPgnm.js              5.51 kB │ gzip:   2.15 kB
dist/assets/CRMIntegration-jylDAreC.js                6.13 kB │ gzip:   2.15 kB
dist/assets/Privacy-Bx1y09Hz.js                       6.16 kB │ gzip:   1.92 kB
dist/assets/radix-primitives-C-4XT4U0.js              6.24 kB │ gzip:   2.01 kB
dist/assets/ConnectionIndicator-BwiDxtzL.js           6.68 kB │ gzip:   2.55 kB
dist/assets/Features-BZRm_x_o.js                      6.73 kB │ gzip:   2.82 kB
dist/assets/CampaignManager-DsmZ6fqx.js               7.31 kB │ gzip:   2.43 kB
dist/assets/MessagingHealth-oGEQQLqi.js               7.35 kB │ gzip:   2.18 kB
dist/assets/EmailIntegration-BAtDQ-_Z.js              7.45 kB │ gzip:   2.44 kB
dist/assets/PreviewHealth-BGH7ZtG9.js                 7.51 kB │ gzip:   2.95 kB
dist/assets/PhoneIntegration-Bvf4LFAf.js              7.54 kB │ gzip:   2.27 kB
dist/assets/lovableSaveFailsafe-B9546M9k.js           7.68 kB │ gzip:   2.48 kB
dist/assets/Pricing-ZC5oWQu_.js                       8.11 kB │ gzip:   2.87 kB
dist/assets/MessagingIntegration-C0B3yVpa.js          8.26 kB │ gzip:   2.76 kB
dist/assets/TwilioEvidence-Ccx6B830.js                9.45 kB │ gzip:   2.59 kB
dist/assets/browser-ponyfill-Bir_r7zy.js              9.99 kB │ gzip:   3.44 kB
dist/assets/FAQ-B6hv48uz.js                          10.10 kB │ gzip:   3.84 kB
dist/assets/MiniChat-BGs3UKEv.js                     10.31 kB │ gzip:   3.89 kB
dist/assets/MobileIntegration-cruJy9p2.js            10.48 kB │ gzip:   2.75 kB
dist/assets/Auth-9mOS3ztX.js                         10.48 kB │ gzip:   3.34 kB
dist/assets/AutomationIntegration-9Nk_Iuhe.js        10.56 kB │ gzip:   3.35 kB
dist/assets/ClientDashboard-B8DEMRr7.js              11.38 kB │ gzip:   3.46 kB
dist/assets/Contact-CGcYDDlX.js                      11.52 kB │ gzip:   3.89 kB
dist/assets/CallCenter-B4spXEbA.js                   11.53 kB │ gzip:   4.13 kB
dist/assets/VoiceSettings-siZf4bCu.js                14.30 kB │ gzip:   4.35 kB
dist/assets/VoiceHealth-e2v1P9vM.js                  14.49 kB │ gzip:   3.02 kB
dist/assets/Security-CtYkaqQP.js                     14.67 kB │ gzip:   4.41 kB
dist/assets/ClientNumberOnboarding-DR3sBFKl.js       18.89 kB │ gzip:   5.35 kB
dist/assets/CallLogs-CmW44ojl.js                     22.61 kB │ gzip:   7.26 kB
dist/assets/radix-forms-uNGDj7-j.js                  32.09 kB │ gzip:  10.58 kB
dist/assets/react-router-OXQyrdz8.js                 34.20 kB │ gzip:  12.46 kB
dist/assets/NewDashboard-BgfjIn09.js                 36.44 kB │ gzip:   9.98 kB
dist/assets/radix-overlays-C7AmMIQn.js               91.96 kB │ gzip:  29.03 kB
dist/assets/react-vendor-CCDPu1A0.js                139.88 kB │ gzip:  45.14 kB
dist/assets/supabase-CzaIJPsd.js                    186.83 kB │ gzip:  47.03 kB
dist/assets/index-Cm0z0gui.js                       340.21 kB │ gzip:  97.42 kB
✓ built in 6.68s

> vite_react_shadcn_ts@1.0.7 postbuild
> npm run verify:app && npm run verify:icons && npm run verify:console


> vite_react_shadcn_ts@1.0.7 verify:app
> node scripts/verify-app.cjs

Node.js v20.19.0
[verify] Probing http://127.0.0.1:4176/
  ➜  Local:   http://127.0.0.1:4176/
VERIFY: PASS

> vite_react_shadcn_ts@1.0.7 verify:icons
> node scripts/verify_icons.mjs

iOS 1024 icon already present -> ios/App/App/Assets.xcassets/AppIcon.appiconset/icon-1024.png
✅ Icon set verified.

> vite_react_shadcn_ts@1.0.7 verify:console
> node scripts/verify-console-usage.mjs

🔍 Verifying console usage in critical files...

📄 Checking src/main.tsx...
✅ src/main.tsx passed validation

✅ All console usage checks passed!
Verify App Store Connect secrets (fail fast)
< 1s



Show command

Install CocoaPods
32s



Show command
[info] Using Gemfile: RubyGems bundle installed

> vite_react_shadcn_ts@1.0.7 prebuild
> node scripts/check-required-files.mjs

✅ All required files found

> vite_react_shadcn_ts@1.0.7 build
> vite build

vite v7.3.0 building client environment for production...
transforming...
node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (46:10): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs (94:21): "default" is not exported by "node_modules/@supabase/supabase-js/dist/module/index.js", imported by "node_modules/@supabase/supabase-js/dist/esm/wrapper.mjs".
✓ 2387 modules transformed.
rendering chunks...
[plugin vite:reporter] 
(!) /Users/builder/clone/src/lib/errorReporter.ts is dynamically imported by /Users/builder/clone/src/hooks/useAuth.ts but also statically imported by /Users/builder/clone/src/components/dashboard/QuickActionsCard.tsx, /Users/builder/clone/src/components/dashboard/new/WinsSection.tsx, /Users/builder/clone/src/components/errors/SafeErrorBoundary.tsx, /Users/builder/clone/src/components/sections/LeadCaptureCard.tsx, /Users/builder/clone/src/components/sections/LeadCaptureForm.tsx, /Users/builder/clone/src/components/ui/MiniChat.tsx, /Users/builder/clone/src/hooks/useAnalytics.ts, /Users/builder/clone/src/hooks/useAuth.ts, /Users/builder/clone/src/hooks/useEnhancedDashboard.ts, /Users/builder/clone/src/hooks/usePasswordSecurity.ts, /Users/builder/clone/src/hooks/useSafeNavigation.ts, /Users/builder/clone/src/hooks/useSecureABTest.ts, /Users/builder/clone/src/hooks/useSecureAnalytics.ts, /Users/builder/clone/src/hooks/useSecureFormSubmission.ts, /Users/builder/clone/src/hooks/useTwilioCallData.ts, /Users/builder/clone/src/lib/ensureMembership.ts, /Users/builder/clone/src/lib/pwaInstall.ts, /Users/builder/clone/src/lib/swCleanup.ts, /Users/builder/clone/src/pages/Auth.tsx, /Users/builder/clone/src/pages/Contact.tsx, /Users/builder/clone/src/pages/Index.tsx, /Users/builder/clone/src/utils/safetyHelpers.ts, dynamic import will not move module into another chunk.

computing gzip size...
dist/assets/apex-wordmark-DoKihJda.png               17.66 kB
dist/index.html                                      21.22 kB │ gzip:   6.43 kB
dist/assets/alberta-innovates-BjA-ej2W.png           41.57 kB
dist/assets/official-logo-CJuizMTY.png               50.37 kB
dist/assets/erin-IH91Xwvd.png                       304.67 kB
dist/assets/built-canadian-AypIzTtN.svg             758.45 kB │ gzip: 570.78 kB
dist/assets/BACKGROUND_IMAGE1-BmVn5_cx.svg        1,065.27 kB │ gzip: 300.30 kB
dist/assets/roi-table-gLrgCKri.css                    0.85 kB │ gzip:   0.40 kB
dist/assets/index-BuaQgkEF.css                        3.11 kB │ gzip:   1.08 kB
dist/assets/index-DYv08kny.css                      151.37 kB │ gzip:  25.25 kB
dist/assets/arrow-left-l0AoTFi5.js                    0.16 kB │ gzip:   0.16 kB
dist/assets/circle-check-CBevw9yK.js                  0.18 kB │ gzip:   0.16 kB
dist/assets/circle-x-X6ITLRE8.js                      0.20 kB │ gzip:   0.17 kB
dist/assets/message-square-BlJli4rx.js                0.23 kB │ gzip:   0.19 kB
dist/assets/message-circle-Chuq2fS3.js                0.23 kB │ gzip:   0.20 kB
dist/assets/database-DGhCcaZ7.js                      0.24 kB │ gzip:   0.19 kB
dist/assets/external-link--Uh018tL.js                 0.24 kB │ gzip:   0.19 kB
dist/assets/circle-alert-B_rJ3fpN.js                  0.25 kB │ gzip:   0.18 kB
dist/assets/map-pin-CNX8frrY.js                       0.25 kB │ gzip:   0.22 kB
dist/assets/calendar-D-CwI73W.js                      0.25 kB │ gzip:   0.20 kB
dist/assets/key-BFWFxK4T.js                           0.26 kB │ gzip:   0.21 kB
dist/assets/send-Cx3ryKnc.js                          0.28 kB │ gzip:   0.22 kB
dist/assets/users-CmRlGVsq.js                         0.30 kB │ gzip:   0.22 kB
dist/assets/refresh-cw-KQ2EnFhL.js                    0.31 kB │ gzip:   0.22 kB
dist/assets/brandGradients-KgJGh5c5.js                0.44 kB │ gzip:   0.25 kB
dist/assets/performanceOptimizations-DPwb1cGZ.js      0.53 kB │ gzip:   0.29 kB
dist/assets/errorObservability-DaB9InDk.js            0.58 kB │ gzip:   0.35 kB
dist/assets/react-query-DdKjlrul.js                   0.76 kB │ gzip:   0.49 kB
dist/assets/LoginPage-B6UwNWGI.js                     0.80 kB │ gzip:   0.47 kB
dist/assets/roiTableFix-Cr-xS_7t.js                   0.89 kB │ gzip:   0.42 kB
dist/assets/web-gvg0Juk9.js                           1.00 kB │ gzip:   0.47 kB
dist/assets/heroGuardian-22GY0CLt.js                  1.43 kB │ gzip:   0.70 kB
dist/assets/PWAInstallBanner-BJflqhXE.js              1.67 kB │ gzip:   0.82 kB
dist/assets/SEOHead-CFHI398J.js                       1.74 kB │ gzip:   0.71 kB
dist/assets/pwaInstall-6I8o5I8e.js                    1.96 kB │ gzip:   0.91 kB
dist/assets/index-Ce24umrQ.js                         2.30 kB │ gzip:   1.03 kB
dist/assets/select-Cl8Z79z-.js                        3.07 kB │ gzip:   1.14 kB
dist/assets/AuthLanding-CbCFg7QN.js                   3.16 kB │ gzip:   1.42 kB
dist/assets/tabs-B1ZOdcDR.js                          3.35 kB │ gzip:   1.43 kB
dist/assets/PhoneApps-dRK20II_.js                     3.46 kB │ gzip:   1.45 kB
dist/assets/index-Cl17-L-9.js                         3.50 kB │ gzip:   1.59 kB
dist/assets/NotFound-CDO9_uaF.js                      3.81 kB │ gzip:   1.48 kB
dist/assets/lovableGitHubMonitor-DNEumbYB.js          4.10 kB │ gzip:   1.59 kB
dist/assets/TeamInvite-BNL1M3K8.js                    4.11 kB │ gzip:   1.71 kB
dist/assets/Compare-CRBGXjaN.js                       5.33 kB │ gzip:   1.67 kB
dist/assets/Integrations-DeoBdyOz.js                  5.44 kB │ gzip:   2.00 kB
dist/assets/ForwardingWizard-n-SgPgnm.js              5.51 kB │ gzip:   2.15 kB
dist/assets/CRMIntegration-jylDAreC.js                6.13 kB │ gzip:   2.15 kB
dist/assets/Privacy-Bx1y09Hz.js                       6.16 kB │ gzip:   1.92 kB
dist/assets/radix-primitives-C-4XT4U0.js              6.24 kB │ gzip:   2.01 kB
dist/assets/ConnectionIndicator-BwiDxtzL.js           6.68 kB │ gzip:   2.55 kB
dist/assets/Features-BZRm_x_o.js                      6.73 kB │ gzip:   2.82 kB
dist/assets/CampaignManager-DsmZ6fqx.js               7.31 kB │ gzip:   2.43 kB
dist/assets/MessagingHealth-oGEQQLqi.js               7.35 kB │ gzip:   2.18 kB
dist/assets/EmailIntegration-BAtDQ-_Z.js              7.45 kB │ gzip:   2.44 kB
dist/assets/PreviewHealth-BGH7ZtG9.js                 7.51 kB │ gzip:   2.95 kB
dist/assets/PhoneIntegration-Bvf4LFAf.js              7.54 kB │ gzip:   2.27 kB
dist/assets/lovableSaveFailsafe-B9546M9k.js           7.68 kB │ gzip:   2.48 kB
dist/assets/Pricing-ZC5oWQu_.js                       8.11 kB │ gzip:   2.87 kB
dist/assets/MessagingIntegration-C0B3yVpa.js          8.26 kB │ gzip:   2.76 kB
dist/assets/TwilioEvidence-Ccx6B830.js                9.45 kB │ gzip:   2.59 kB
dist/assets/browser-ponyfill-Bir_r7zy.js              9.99 kB │ gzip:   3.44 kB
dist/assets/FAQ-B6hv48uz.js                          10.10 kB │ gzip:   3.84 kB
dist/assets/MiniChat-BGs3UKEv.js                     10.31 kB │ gzip:   3.89 kB
dist/assets/MobileIntegration-cruJy9p2.js            10.48 kB │ gzip:   2.75 kB
dist/assets/Auth-9mOS3ztX.js                         10.48 kB │ gzip:   3.34 kB
dist/assets/AutomationIntegration-9Nk_Iuhe.js        10.56 kB │ gzip:   3.35 kB
dist/assets/ClientDashboard-B8DEMRr7.js              11.38 kB │ gzip:   3.46 kB
dist/assets/Contact-CGcYDDlX.js                      11.52 kB │ gzip:   3.89 kB
dist/assets/CallCenter-B4spXEbA.js                   11.53 kB │ gzip:   4.13 kB
dist/assets/VoiceSettings-siZf4bCu.js                14.30 kB │ gzip:   4.35 kB
dist/assets/VoiceHealth-e2v1P9vM.js                  14.49 kB │ gzip:   3.02 kB
dist/assets/Security-CtYkaqQP.js                     14.67 kB │ gzip:   4.41 kB
dist/assets/ClientNumberOnboarding-DR3sBFKl.js       18.89 kB │ gzip:   5.35 kB
dist/assets/CallLogs-CmW44ojl.js                     22.61 kB │ gzip:   7.26 kB
dist/assets/radix-forms-uNGDj7-j.js                  32.09 kB │ gzip:  10.58 kB
dist/assets/react-router-OXQyrdz8.js                 34.20 kB │ gzip:  12.46 kB
dist/assets/NewDashboard-BgfjIn09.js                 36.44 kB │ gzip:   9.98 kB
dist/assets/radix-overlays-C7AmMIQn.js               91.96 kB │ gzip:  29.03 kB
dist/assets/react-vendor-CCDPu1A0.js                139.88 kB │ gzip:  45.14 kB
dist/assets/supabase-CzaIJPsd.js                    186.83 kB │ gzip:  47.03 kB
dist/assets/index-Cm0z0gui.js                       340.21 kB │ gzip:  97.42 kB
✓ built in 6.73s

> vite_react_shadcn_ts@1.0.7 postbuild
> npm run verify:app && npm run verify:icons && npm run verify:console


> vite_react_shadcn_ts@1.0.7 verify:app
> node scripts/verify-app.cjs

Node.js v20.19.0
[verify] Probing http://127.0.0.1:4176/
  ➜  Local:   http://127.0.0.1:4176/
VERIFY: PASS

> vite_react_shadcn_ts@1.0.7 verify:icons
> node scripts/verify_icons.mjs

iOS 1024 icon already present -> ios/App/App/Assets.xcassets/AppIcon.appiconset/icon-1024.png
✅ Icon set verified.
> vite_react_shadcn_ts@1.0.7 verify:console
> node scripts/verify-console-usage.mjs

🔍 Verifying console usage in critical files...

📄 Checking src/main.tsx...
✅ src/main.tsx passed validation

✅ All console usage checks passed!
✔ Copying web assets from dist to ios/App/App/public in 39.54ms
✔ Creating capacitor.config.json in ios/App/App in 950.33μs
✔ copy ios in 95.46ms
✔ Updating iOS plugins in 11.09ms
✔ Updating iOS native dependencies with pod install in 2.30s
[info] Found 6 Capacitor plugins for ios:
       @capacitor/app@7.1.1
       @capacitor/haptics@7.0.3
       @capacitor/local-notifications@7.0.4
       @capacitor/network@7.0.3
       @capacitor/preferences@7.0.3
       @capacitor/push-notifications@7.0.4
✔ update ios in 2.35s
[info] Sync finished in 31.048s

Install CocoaPods
1s



Show command
Updating local specs repositories
Analyzing dependencies
Downloading dependencies
Generating Pods project
Integrating client project
Pod installation complete! There are 8 dependencies from the Podfile and 8 total pods installed.

[!] Your project does not explicitly specify the CocoaPods master specs repo. Since CDN is now used as the default, you may safely remove it from your repos directory via `pod repo remove master`. To suppress this warning please add `warn_for_unused_master_specs_repo => false` to your Podfile.

Set iOS version/build (1.0.7 + ASC-max+1)
2s



Show command
🔍 Fetching build numbers for app $APP_STORE_ID version 1.0.7...
📝 No existing builds found for version 1.0.7 train, using 0
📝 No existing builds found overall, using 0
🎯 Overall build higher, using: 1 (train=0, overall=0)
🔧 Setting iOS version: 1.0.7 (build 1)
Setting CFBundleShortVersionString of project App to: 
    1.0.7.

Updating CFBundleShortVersionString in Info.plist(s)...

Updated CFBundleShortVersionString in "App.xcodeproj/../App/Info.plist" to 1.0.7
Setting version of project App to: 
    1.

Also setting CFBundleVersion key (assuming it exists)

Updating CFBundleVersion in Info.plist(s)...

Updated CFBundleVersion in "App.xcodeproj/../App/Info.plist" to 1


🔍 Verifying version settings...
No marketing version number (CFBundleShortVersionString) found for Jambase targets.

Looking for marketing version in native targets...
Looking for marketing version (CFBundleShortVersionString) in native targets...

Found CFBundleShortVersionString of "1.0.7" in "App.xcodeproj/../App/Info.plist" 
Current version of project App is: 
    1

✅ Set version=1.0.7 build=1 (train=0 overall=0)

Configure code signing
1s



Show command
Configure code signing settings
Searching for files matching /Users/builder/Library/MobileDevice/Provisioning Profiles/*.mobileprovision
Searching for files matching /Users/builder/Library/MobileDevice/Provisioning Profiles/*.provisionprofile
List available code signing certificates in keychain /Users/builder/Library/codemagic-cli-tools/keychains/29-12-25_beiomf7s.keychain-db
Searching for files matching /Users/builder/clone/**/*.xcodeproj
Completed configuring code signing settings
 - Using profile "TL247_mobpro_tradeline_01" [50b2de01-f6c3-46f3-b40f-ee44cac4454d] for target "App" [Debug] from project "App"
 - Using profile "TL247_mobpro_tradeline_01" [50b2de01-f6c3-46f3-b40f-ee44cac4454d] for target "App" [Release] from project "App"
Generated options for exporting the project
 - Method: app-store
 - Provisioning Profiles:
     - com.apex.tradeline: TL247_mobpro_tradeline_01
 - Signing Certificate: Apple Distribution
 - Signing Style: manual
 - Team Id: NWGUYF42KW
 - Test Flight Internal Testing Only: True
Saved export options to /Users/builder/export_options.plist

Build archive & IPA
58s



Show command
Using Xcode 16.4 (16F6)
Check App.xcworkspace build settings
Execute "xcodebuild -workspace ios/App/App.xcworkspace -scheme App -config Release -showBuildSettings"

Archive App.xcworkspace
Execute "xcodebuild -workspace ios/App/App.xcworkspace -scheme App -config Release -destination generic/platform=iOS -archivePath /Users/builder/clone/build/ios/xcarchive/App_8ezrrz61.xcarchive archive COMPILER_INDEX_STORE_ENABLE=NO DEVELOPMENT_TEAM=NWGUYF42KW 'CODE_SIGN_IDENTITY=Apple Distribution' CODE_SIGN_STYLE=Manual"

▸ Copying Pods-App-umbrella.h
▸ Copying CapacitorPreferences-umbrella.h
▸ Copying CapacitorPushNotifications-umbrella.h
▸ Copying CapacitorNetwork-umbrella.h
▸ Copying CapacitorLocalNotifications-umbrella.h
▸ Copying CapacitorHaptics-umbrella.h
▸ Copying NSDictionary+CordovaPreferences.h
▸ Copying CapacitorCordova.h
▸ Copying CDVWebViewProcessPoolFactory.h
▸ Copying CDVViewController.h
▸ Copying CDVURLProtocol.h
▸ Copying CDVScreenOrientationDelegate.h
▸ Copying CDVPluginResult.h
▸ Copying CDVPluginManager.h
▸ Copying CDVPlugin.h
▸ Copying CDVPlugin+Resources.h
▸ Copying CDVInvokedUrlCommand.h
▸ Copying CDVConfigParser.h
▸ Copying CDVCommandDelegateImpl.h
▸ Copying CDVCommandDelegate.h
▸ Copying CDVAvailability.h
▸ Copying CDV.h
▸ Copying AppDelegate.h
▸ Copying CapacitorApp-umbrella.h
▸ Copying Capacitor.h
▸ Copying CAPPluginMethod.h
▸ Copying CAPPluginCall.h
▸ Copying CAPPlugin.h
▸ Copying CAPInstanceDescriptor.h
▸ Copying CAPInstanceConfiguration.h
▸ Copying CAPBridgedPlugin.h
▸ Copying CAPBridgedJSTypes.h
▸ Copying CAPBridgeViewController+CDVScreenOrientationDelegate.h
▸ Processing CapacitorCordova-Info.plist
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/IntermediateBuildFilesPath/UninstalledProducts/iphoneos/Cordova.framework/PrivacyInfo.xcprivacy
▸ Compiling Cordova_vers.c
▸ Compiling NSDictionary+CordovaPreferences.m
▸ Compiling CDVViewController.m
▸ Compiling CapacitorCordova-dummy.m
▸ Compiling CDVURLProtocol.m
▸ Compiling CDVPluginResult.m
▸ Compiling CDVInvokedUrlCommand.m
▸ Compiling CDVConfigParser.m
▸ Compiling AppDelegate.m
▸ Compiling CDVWebViewProcessPoolFactory.m
▸ Compiling CDVPlugin+Resources.m
▸ Compiling CDVPluginManager.m
▸ Compiling CDVCommandDelegateImpl.m
▸ Compiling CDVPlugin.m
▸ Linking Cordova
▸ Generating 'Cordova.framework.dSYM'
▸ Touching Cordova.framework (in target 'CapacitorCordova' from project 'Pods')
▸ Processing Capacitor-Info.plist
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/IntermediateBuildFilesPath/UninstalledProducts/iphoneos/Capacitor.framework/native-bridge.js
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/IntermediateBuildFilesPath/UninstalledProducts/iphoneos/Capacitor.framework/PrivacyInfo.xcprivacy
▸ Compiling Capacitor_vers.c

⚠️  /Users/builder/clone/node_modules/@capacitor/push-notifications/ios/Sources/PushNotificationsPlugin/PushNotificationsHandler.swift:38:49: 'alert' was deprecated in iOS 14.0

                    presentationOptions.insert(.alert)
                                                ^



⚠️  /Users/builder/clone/node_modules/@capacitor/local-notifications/ios/Sources/LocalNotificationsPlugin/LocalNotificationsHandler.swift:41:14: 'alert' was deprecated in iOS 14.0

            .alert
             ^


▸ Compiling WKWebView+Capacitor.m
▸ Compiling UIStatusBarManager+CAPHandleTapAction.m
▸ Compiling Capacitor-dummy.m
▸ Compiling CAPPluginMethod.m
▸ Compiling CAPPluginCall.m
▸ Compiling CAPPlugin.m
▸ Compiling CAPInstanceDescriptor.m
▸ Compiling CAPInstanceConfiguration.m
▸ Compiling CAPBridgedJSTypes.m
▸ Compiling CAPBridgeViewController+CDVScreenOrientationDelegate.m
▸ Linking Capacitor
▸ Generating 'Capacitor.framework.dSYM'
▸ Touching Capacitor.framework (in target 'Capacitor' from project 'Pods')
▸ Processing CapacitorPreferences-Info.plist
▸ Processing CapacitorPushNotifications-Info.plist
▸ Processing CapacitorNetwork-Info.plist
▸ Processing CapacitorLocalNotifications-Info.plist
▸ Processing CapacitorHaptics-Info.plist
▸ Processing CapacitorApp-Info.plist
▸ Compiling CapacitorHaptics_vers.c
▸ Compiling CapacitorPreferences_vers.c
▸ Compiling CapacitorApp_vers.c
▸ Compiling CapacitorPushNotifications_vers.c
▸ Compiling CapacitorHaptics-dummy.m
▸ Linking CapacitorHaptics
▸ Compiling CapacitorPreferences-dummy.m
▸ Linking CapacitorPreferences
▸ Compiling CapacitorNetwork_vers.c
▸ Generating 'CapacitorHaptics.framework.dSYM'
▸ Generating 'CapacitorPreferences.framework.dSYM'
▸ Touching CapacitorHaptics.framework (in target 'CapacitorHaptics' from project 'Pods')
▸ Touching CapacitorPreferences.framework (in target 'CapacitorPreferences' from project 'Pods')
▸ Compiling CapacitorApp-dummy.m
▸ Linking CapacitorApp
▸ Compiling CapacitorPushNotifications-dummy.m
▸ Linking CapacitorPushNotifications
▸ Generating 'CapacitorApp.framework.dSYM'
▸ Generating 'CapacitorPushNotifications.framework.dSYM'
▸ Touching CapacitorApp.framework (in target 'CapacitorApp' from project 'Pods')
▸ Compiling CapacitorNetwork-dummy.m
▸ Touching CapacitorPushNotifications.framework (in target 'CapacitorPushNotifications' from project 'Pods')
▸ Linking CapacitorNetwork
▸ Generating 'CapacitorNetwork.framework.dSYM'
▸ Touching CapacitorNetwork.framework (in target 'CapacitorNetwork' from project 'Pods')
▸ Compiling CapacitorLocalNotifications_vers.c
▸ Compiling Pods_App_vers.c
▸ Compiling Pods-App-dummy.m
▸ Compiling CapacitorLocalNotifications-dummy.m
▸ Linking CapacitorLocalNotifications
▸ Generating 'CapacitorLocalNotifications.framework.dSYM'
▸ Touching CapacitorLocalNotifications.framework (in target 'CapacitorLocalNotifications' from project 'Pods')
▸ Processing Pods-App-Info.plist
▸ Touching Pods_App.framework (in target 'Pods-App' from project 'Pods')
▸ Running script '[CP] Check Pods Manifest.lock'
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/InstallationBuildProductsLocation/Applications/App.app/public
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/InstallationBuildProductsLocation/Applications/App.app/capacitor.config.json
▸ Copying /Users/builder/Library/Developer/Xcode/DerivedData/App-dfqlwfgrvlmjunbkfzimjqcghcbo/Build/Intermediates.noindex/ArchiveIntermediates/App/InstallationBuildProductsLocation/Applications/App.app/config.xml
▸ Compiling Main.storyboard
▸ Compiling LaunchScreen.storyboard
▸ Compiling App_vers.c
▸ Linking App
▸ Processing Info.plist
▸ Running script '[CP] Embed Pods Frameworks'
▸ Generating 'App.app.dSYM'
▸ Touching App.app (in target 'App' from project 'App')
    Run script build phase '[CP] Embed Pods Frameworks' will be run during every build because it does not specify any outputs. To address this issue, either add output dependencies to the script phase, or configure it to run in every build by unchecking "Based on dependency analysis" in the script phase. (in target 'App' from project 'App')
▸ Archive Succeeded
Successfully created archive at /Users/builder/clone/build/ios/xcarchive/App_8ezrrz61.xcarchive
Export /Users/builder/clone/build/ios/xcarchive/App_8ezrrz61.xcarchive to build/ios/ipa
Execute "xcodebuild -exportArchive -archivePath /Users/builder/clone/build/ios/xcarchive/App_8ezrrz61.xcarchive -exportPath build/ios/ipa -exportOptionsPlist /Users/builder/export_options.plist COMPILER_INDEX_STORE_ENABLE=NO"

▸ Export Succeeded
Successfully exported ipa to build/ios/ipa/App.ipa
Raw xcodebuild logs stored in /tmp/xcodebuild_logs/App.log

Verify IPA version + build (fail-fast preflight)
< 1s



Show command
🎯 Expected version: 1.0.7
🎯 Expected build number: 1
📦 Found IPA: build/ios/ipa/App.ipa
✅ IPA Info.plist: Payload/App.app/Info.plist
✅ IPA Version: 1.0.7
✅ IPA Build:   1
✅ IPA version/build verified. Safe to publish.

Publishing
1m 5s




== Gathering artifacts ==

== Publishing artifacts ==

Publishing artifact App.ipa
Publishing artifact TradeLine247_130_artifacts.zip
Publishing App.ipa to App Store Connect
> app-store-connect publish --path /Users/builder/clone/build/ios/ipa/App.ipa --key-id ******** --issuer-id ******** --private-key @env:APP_STORE_CONNECT_PUBLISHER_PRIVATE_KEY

Publish "/Users/builder/clone/build/ios/ipa/App.ipa" to App Store Connect
App name: TradeLine 24/7
Bundle identifier: com.apex.tradeline
Certificate expires: 2026-10-22T05:47:32.000+0000
Distribution type: App Store
Min OS version: 14.0
Provisioned devices: N/A
Provisions all devices: No
Supported platforms: iPhoneOS
Version code: 1
Version: 1.0.7

Upload "/Users/builder/clone/build/ios/ipa/App.ipa" to App Store Connect
Running altool at path '/Applications/Xcode-16.4.app/Contents/SharedFrameworks/ContentDeliveryServices.framework/Frameworks/AppStoreService.framework/Support/altool'...
Running altool at path '/Applications/Xcode-16.4.app/Contents/SharedFrameworks/ContentDeliveryServices.framework/Frameworks/AppStoreService.framework/Support/altool'...
2025-12-29 00:17:08.063  INFO: [altool.600003EA0180] [ContentDelivery.Uploader.600003EA0180] 
==========================================
UPLOAD SUCCEEDED with 0 warnings, 0 messages
Delivery UUID: b0263920-8ebc-4d17-b107-3e97ba90dee2
Transferred 26258567 bytes in 0.162 seconds (161.7MB/s)
==========================================
{"tool-version":"8.303.16303","tool-path":"\/Applications\/Xcode-16.4.app\/Contents\/SharedFrameworks\/ContentDeliveryServices.framework\/Versions\/A\/Frameworks\/AppStoreService.framework","success-message":"No errors uploading '\/Users\/builder\/clone\/build\/ios\/ipa\/App.ipa'","os-version":"15.5.0"}

No errors uploading '/Users/builder/clone/build/ios/ipa/App.ipa'

Cleaning up
3s



Dependency caching is disabled. Skipping.